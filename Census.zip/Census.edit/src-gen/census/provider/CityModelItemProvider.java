/**
 */
package census.provider;

import census.CensusFactory;
import census.CensusPackage;
import census.CityModel;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link census.CityModel} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class CityModelItemProvider extends ItemProviderAdapter implements IEditingDomainItemProvider,
		IStructuredItemContentProvider, ITreeItemContentProvider, IItemLabelProvider, IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CityModelItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addCitynamePropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Cityname feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCitynamePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_CityModel_cityname_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_CityModel_cityname_feature",
								"_UI_CityModel_type"),
						CensusPackage.Literals.CITY_MODEL__CITYNAME, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(CensusPackage.Literals.CITY_MODEL__HOUSINGSCHEME);
			childrenFeatures.add(CensusPackage.Literals.CITY_MODEL__GOVTRECOM);
			childrenFeatures.add(CensusPackage.Literals.CITY_MODEL__HOSPITAL);
			childrenFeatures.add(CensusPackage.Literals.CITY_MODEL__GRAVEYARD);
			childrenFeatures.add(CensusPackage.Literals.CITY_MODEL__OTHER);
			childrenFeatures.add(CensusPackage.Literals.CITY_MODEL__MOSQUE);
			childrenFeatures.add(CensusPackage.Literals.CITY_MODEL__ROAD);
			childrenFeatures.add(CensusPackage.Literals.CITY_MODEL__PARK);
			childrenFeatures.add(CensusPackage.Literals.CITY_MODEL__SCHOOL);
			childrenFeatures.add(CensusPackage.Literals.CITY_MODEL__HOUSE);
			childrenFeatures.add(CensusPackage.Literals.CITY_MODEL__SECTOR);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns CityModel.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/CityModel"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((CityModel) object).getCityname();
		return label == null || label.length() == 0 ? getString("_UI_CityModel_type")
				: getString("_UI_CityModel_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(CityModel.class)) {
		case CensusPackage.CITY_MODEL__CITYNAME:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		case CensusPackage.CITY_MODEL__HOUSINGSCHEME:
		case CensusPackage.CITY_MODEL__GOVTRECOM:
		case CensusPackage.CITY_MODEL__HOSPITAL:
		case CensusPackage.CITY_MODEL__GRAVEYARD:
		case CensusPackage.CITY_MODEL__OTHER:
		case CensusPackage.CITY_MODEL__MOSQUE:
		case CensusPackage.CITY_MODEL__ROAD:
		case CensusPackage.CITY_MODEL__PARK:
		case CensusPackage.CITY_MODEL__SCHOOL:
		case CensusPackage.CITY_MODEL__HOUSE:
		case CensusPackage.CITY_MODEL__SECTOR:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add(createChildParameter(CensusPackage.Literals.CITY_MODEL__HOUSINGSCHEME,
				CensusFactory.eINSTANCE.createHousingScheme()));

		newChildDescriptors.add(createChildParameter(CensusPackage.Literals.CITY_MODEL__GOVTRECOM,
				CensusFactory.eINSTANCE.createGovtRecom()));

		newChildDescriptors.add(createChildParameter(CensusPackage.Literals.CITY_MODEL__HOSPITAL,
				CensusFactory.eINSTANCE.createHospital()));

		newChildDescriptors.add(createChildParameter(CensusPackage.Literals.CITY_MODEL__GRAVEYARD,
				CensusFactory.eINSTANCE.createGraveyard()));

		newChildDescriptors.add(
				createChildParameter(CensusPackage.Literals.CITY_MODEL__OTHER, CensusFactory.eINSTANCE.createOther()));

		newChildDescriptors.add(createChildParameter(CensusPackage.Literals.CITY_MODEL__MOSQUE,
				CensusFactory.eINSTANCE.createMosque()));

		newChildDescriptors.add(createChildParameter(CensusPackage.Literals.CITY_MODEL__ROAD,
				CensusFactory.eINSTANCE.createMainRoad()));

		newChildDescriptors.add(createChildParameter(CensusPackage.Literals.CITY_MODEL__ROAD,
				CensusFactory.eINSTANCE.createStreetRoad()));

		newChildDescriptors.add(createChildParameter(CensusPackage.Literals.CITY_MODEL__ROAD,
				CensusFactory.eINSTANCE.createServiceRoad()));

		newChildDescriptors.add(
				createChildParameter(CensusPackage.Literals.CITY_MODEL__PARK, CensusFactory.eINSTANCE.createPark()));

		newChildDescriptors.add(createChildParameter(CensusPackage.Literals.CITY_MODEL__SCHOOL,
				CensusFactory.eINSTANCE.createSchool()));

		newChildDescriptors.add(
				createChildParameter(CensusPackage.Literals.CITY_MODEL__HOUSE, CensusFactory.eINSTANCE.createHouse()));

		newChildDescriptors.add(createChildParameter(CensusPackage.Literals.CITY_MODEL__SECTOR,
				CensusFactory.eINSTANCE.createSector()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return CensusEditPlugin.INSTANCE;
	}

}

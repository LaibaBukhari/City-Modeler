/**
 */
package census.provider;

import census.CensusFactory;
import census.CensusPackage;
import census.Sector;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link census.Sector} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class SectorItemProvider extends ItemProviderAdapter implements IEditingDomainItemProvider,
		IStructuredItemContentProvider, ITreeItemContentProvider, IItemLabelProvider, IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SectorItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addSectornamePropertyDescriptor(object);
			addSectorpopuPropertyDescriptor(object);
			addNofhousesPropertyDescriptor(object);
			addNofroadsPropertyDescriptor(object);
			addNofschoolsPropertyDescriptor(object);
			addNofparksPropertyDescriptor(object);
			addNofmosquesPropertyDescriptor(object);
			addNofhospitalsPropertyDescriptor(object);
			addNofgraveyardsPropertyDescriptor(object);
			addNofothersPropertyDescriptor(object);
			addGovtrecomPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Sectorname feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addSectornamePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Sector_sectorname_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Sector_sectorname_feature",
								"_UI_Sector_type"),
						CensusPackage.Literals.SECTOR__SECTORNAME, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Sectorpopu feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addSectorpopuPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Sector_sectorpopu_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Sector_sectorpopu_feature",
								"_UI_Sector_type"),
						CensusPackage.Literals.SECTOR__SECTORPOPU, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Nofhouses feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNofhousesPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Sector_nofhouses_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Sector_nofhouses_feature",
								"_UI_Sector_type"),
						CensusPackage.Literals.SECTOR__NOFHOUSES, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Nofroads feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNofroadsPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Sector_nofroads_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Sector_nofroads_feature",
								"_UI_Sector_type"),
						CensusPackage.Literals.SECTOR__NOFROADS, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Nofschools feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNofschoolsPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Sector_nofschools_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Sector_nofschools_feature",
								"_UI_Sector_type"),
						CensusPackage.Literals.SECTOR__NOFSCHOOLS, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Nofparks feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNofparksPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Sector_nofparks_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Sector_nofparks_feature",
								"_UI_Sector_type"),
						CensusPackage.Literals.SECTOR__NOFPARKS, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Nofmosques feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNofmosquesPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Sector_nofmosques_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Sector_nofmosques_feature",
								"_UI_Sector_type"),
						CensusPackage.Literals.SECTOR__NOFMOSQUES, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Nofhospitals feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNofhospitalsPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Sector_nofhospitals_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Sector_nofhospitals_feature",
								"_UI_Sector_type"),
						CensusPackage.Literals.SECTOR__NOFHOSPITALS, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Nofgraveyards feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNofgraveyardsPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Sector_nofgraveyards_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Sector_nofgraveyards_feature",
								"_UI_Sector_type"),
						CensusPackage.Literals.SECTOR__NOFGRAVEYARDS, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Nofothers feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNofothersPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Sector_nofothers_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Sector_nofothers_feature",
								"_UI_Sector_type"),
						CensusPackage.Literals.SECTOR__NOFOTHERS, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Govtrecom feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addGovtrecomPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Sector_govtrecom_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Sector_govtrecom_feature",
								"_UI_Sector_type"),
						CensusPackage.Literals.SECTOR__GOVTRECOM, true, false, true, null, null, null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(CensusPackage.Literals.SECTOR__SCHOOL);
			childrenFeatures.add(CensusPackage.Literals.SECTOR__PARK);
			childrenFeatures.add(CensusPackage.Literals.SECTOR__MOSQUE);
			childrenFeatures.add(CensusPackage.Literals.SECTOR__OTHER);
			childrenFeatures.add(CensusPackage.Literals.SECTOR__GRAVEYARD);
			childrenFeatures.add(CensusPackage.Literals.SECTOR__HOSPITAL);
			childrenFeatures.add(CensusPackage.Literals.SECTOR__HOUSE);
			childrenFeatures.add(CensusPackage.Literals.SECTOR__ROAD);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns Sector.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Sector"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((Sector) object).getSectorname();
		return label == null || label.length() == 0 ? getString("_UI_Sector_type")
				: getString("_UI_Sector_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Sector.class)) {
		case CensusPackage.SECTOR__SECTORNAME:
		case CensusPackage.SECTOR__SECTORPOPU:
		case CensusPackage.SECTOR__NOFHOUSES:
		case CensusPackage.SECTOR__NOFROADS:
		case CensusPackage.SECTOR__NOFSCHOOLS:
		case CensusPackage.SECTOR__NOFPARKS:
		case CensusPackage.SECTOR__NOFMOSQUES:
		case CensusPackage.SECTOR__NOFHOSPITALS:
		case CensusPackage.SECTOR__NOFGRAVEYARDS:
		case CensusPackage.SECTOR__NOFOTHERS:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		case CensusPackage.SECTOR__SCHOOL:
		case CensusPackage.SECTOR__PARK:
		case CensusPackage.SECTOR__MOSQUE:
		case CensusPackage.SECTOR__OTHER:
		case CensusPackage.SECTOR__GRAVEYARD:
		case CensusPackage.SECTOR__HOSPITAL:
		case CensusPackage.SECTOR__HOUSE:
		case CensusPackage.SECTOR__ROAD:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add(
				createChildParameter(CensusPackage.Literals.SECTOR__SCHOOL, CensusFactory.eINSTANCE.createSchool()));

		newChildDescriptors
				.add(createChildParameter(CensusPackage.Literals.SECTOR__PARK, CensusFactory.eINSTANCE.createPark()));

		newChildDescriptors.add(
				createChildParameter(CensusPackage.Literals.SECTOR__MOSQUE, CensusFactory.eINSTANCE.createMosque()));

		newChildDescriptors
				.add(createChildParameter(CensusPackage.Literals.SECTOR__OTHER, CensusFactory.eINSTANCE.createOther()));

		newChildDescriptors.add(createChildParameter(CensusPackage.Literals.SECTOR__GRAVEYARD,
				CensusFactory.eINSTANCE.createGraveyard()));

		newChildDescriptors.add(createChildParameter(CensusPackage.Literals.SECTOR__HOSPITAL,
				CensusFactory.eINSTANCE.createHospital()));

		newChildDescriptors
				.add(createChildParameter(CensusPackage.Literals.SECTOR__HOUSE, CensusFactory.eINSTANCE.createHouse()));

		newChildDescriptors.add(
				createChildParameter(CensusPackage.Literals.SECTOR__ROAD, CensusFactory.eINSTANCE.createMainRoad()));

		newChildDescriptors.add(
				createChildParameter(CensusPackage.Literals.SECTOR__ROAD, CensusFactory.eINSTANCE.createStreetRoad()));

		newChildDescriptors.add(
				createChildParameter(CensusPackage.Literals.SECTOR__ROAD, CensusFactory.eINSTANCE.createServiceRoad()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return CensusEditPlugin.INSTANCE;
	}

}

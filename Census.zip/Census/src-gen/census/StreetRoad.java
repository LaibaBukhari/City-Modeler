/**
 */
package census;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Street Road</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see census.CensusPackage#getStreetRoad()
 * @model
 * @generated
 */
public interface StreetRoad extends Road {
} // StreetRoad

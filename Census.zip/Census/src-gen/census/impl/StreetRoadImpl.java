/**
 */
package census.impl;

import census.CensusPackage;
import census.StreetRoad;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Street Road</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class StreetRoadImpl extends RoadImpl implements StreetRoad {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StreetRoadImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CensusPackage.Literals.STREET_ROAD;
	}

} //StreetRoadImpl

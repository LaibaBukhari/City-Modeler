/**
 */
package census.impl;

import census.CensusFactory;
import census.CensusPackage;
import census.CityModel;
import census.GovtRecom;
import census.Graveyard;
import census.Hospital;
import census.House;
import census.HousingScheme;
import census.MainRoad;
import census.Mosque;
import census.Other;
import census.Park;
import census.Road;
import census.School;
import census.Sector;
import census.ServiceRoad;
import census.StreetRoad;

import census.util.CensusValidator;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CensusPackageImpl extends EPackageImpl implements CensusPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cityModelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass housingSchemeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sectorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass schoolEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass parkEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mosqueEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hospitalEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass graveyardEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass otherEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass houseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass roadEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mainRoadEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass streetRoadEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass serviceRoadEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass govtRecomEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see census.CensusPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private CensusPackageImpl() {
		super(eNS_URI, CensusFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link CensusPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static CensusPackage init() {
		if (isInited)
			return (CensusPackage) EPackage.Registry.INSTANCE.getEPackage(CensusPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredCensusPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		CensusPackageImpl theCensusPackage = registeredCensusPackage instanceof CensusPackageImpl
				? (CensusPackageImpl) registeredCensusPackage
				: new CensusPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theCensusPackage.createPackageContents();

		// Initialize created meta-data
		theCensusPackage.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put(theCensusPackage, new EValidator.Descriptor() {
			public EValidator getEValidator() {
				return CensusValidator.INSTANCE;
			}
		});

		// Mark meta-data to indicate it can't be changed
		theCensusPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(CensusPackage.eNS_URI, theCensusPackage);
		return theCensusPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCityModel() {
		return cityModelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCityModel_Cityname() {
		return (EAttribute) cityModelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCityModel_Housingscheme() {
		return (EReference) cityModelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCityModel_Govtrecom() {
		return (EReference) cityModelEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCityModel_Hospital() {
		return (EReference) cityModelEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCityModel_Graveyard() {
		return (EReference) cityModelEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCityModel_Other() {
		return (EReference) cityModelEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCityModel_Mosque() {
		return (EReference) cityModelEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCityModel_Road() {
		return (EReference) cityModelEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCityModel_Park() {
		return (EReference) cityModelEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCityModel_School() {
		return (EReference) cityModelEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCityModel_House() {
		return (EReference) cityModelEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCityModel_Sector() {
		return (EReference) cityModelEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getHousingScheme() {
		return housingSchemeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHousingScheme_Schemename() {
		return (EAttribute) housingSchemeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHousingScheme_Schemepopu() {
		return (EAttribute) housingSchemeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHousingScheme_Totalnofhouses() {
		return (EAttribute) housingSchemeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHousingScheme_Totalnofroads() {
		return (EAttribute) housingSchemeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHousingScheme_Totalnofschools() {
		return (EAttribute) housingSchemeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHousingScheme_Totalnofparks() {
		return (EAttribute) housingSchemeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHousingScheme_Totalnofmosques() {
		return (EAttribute) housingSchemeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHousingScheme_Totalnofhospitals() {
		return (EAttribute) housingSchemeEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHousingScheme_Totalnofgraveyards() {
		return (EAttribute) housingSchemeEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHousingScheme_Totalnofothers() {
		return (EAttribute) housingSchemeEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHousingScheme_Totalnofsectors() {
		return (EAttribute) housingSchemeEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHousingScheme_Sector() {
		return (EReference) housingSchemeEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHousingScheme_Govtrecom() {
		return (EReference) housingSchemeEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getHousingScheme__Compare() {
		return housingSchemeEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSector() {
		return sectorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSector_Sectorname() {
		return (EAttribute) sectorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSector_Sectorpopu() {
		return (EAttribute) sectorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSector_Nofhouses() {
		return (EAttribute) sectorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSector_Nofroads() {
		return (EAttribute) sectorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSector_Nofschools() {
		return (EAttribute) sectorEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSector_Nofparks() {
		return (EAttribute) sectorEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSector_Nofmosques() {
		return (EAttribute) sectorEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSector_Nofhospitals() {
		return (EAttribute) sectorEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSector_Nofgraveyards() {
		return (EAttribute) sectorEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSector_Nofothers() {
		return (EAttribute) sectorEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSector_School() {
		return (EReference) sectorEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSector_Park() {
		return (EReference) sectorEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSector_Mosque() {
		return (EReference) sectorEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSector_Other() {
		return (EReference) sectorEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSector_Graveyard() {
		return (EReference) sectorEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSector_Hospital() {
		return (EReference) sectorEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSector_House() {
		return (EReference) sectorEClass.getEStructuralFeatures().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSector_Road() {
		return (EReference) sectorEClass.getEStructuralFeatures().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSector_Govtrecom() {
		return (EReference) sectorEClass.getEStructuralFeatures().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getSector__Compare() {
		return sectorEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSchool() {
		return schoolEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSchool_Schoolname() {
		return (EAttribute) schoolEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSchool_Schoolcapacity() {
		return (EAttribute) schoolEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPark() {
		return parkEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPark_Parkname() {
		return (EAttribute) parkEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPark_Parkcapacity() {
		return (EAttribute) parkEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMosque() {
		return mosqueEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMosque_Mosquename() {
		return (EAttribute) mosqueEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMosque_Mosquecapacity() {
		return (EAttribute) mosqueEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getHospital() {
		return hospitalEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHospital_Hospitalname() {
		return (EAttribute) hospitalEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHospital_Nofbeds() {
		return (EAttribute) hospitalEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGraveyard() {
		return graveyardEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGraveyard_Graveyardname() {
		return (EAttribute) graveyardEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGraveyard_Graveyardcapacity() {
		return (EAttribute) graveyardEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOther() {
		return otherEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOther_Othername() {
		return (EAttribute) otherEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOther_Othercapacity() {
		return (EAttribute) otherEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getHouse() {
		return houseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHouse_Housenbr() {
		return (EAttribute) houseEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHouse_Streetnbr() {
		return (EAttribute) houseEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHouse_Nofpeople() {
		return (EAttribute) houseEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRoad() {
		return roadEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRoad_Roadname() {
		return (EAttribute) roadEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMainRoad() {
		return mainRoadEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStreetRoad() {
		return streetRoadEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getServiceRoad() {
		return serviceRoadEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGovtRecom() {
		return govtRecomEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGovtRecom_SchemePopuControl() {
		return (EAttribute) govtRecomEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGovtRecom_SectorPopuControl() {
		return (EAttribute) govtRecomEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CensusFactory getCensusFactory() {
		return (CensusFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		cityModelEClass = createEClass(CITY_MODEL);
		createEAttribute(cityModelEClass, CITY_MODEL__CITYNAME);
		createEReference(cityModelEClass, CITY_MODEL__HOUSINGSCHEME);
		createEReference(cityModelEClass, CITY_MODEL__GOVTRECOM);
		createEReference(cityModelEClass, CITY_MODEL__HOSPITAL);
		createEReference(cityModelEClass, CITY_MODEL__GRAVEYARD);
		createEReference(cityModelEClass, CITY_MODEL__OTHER);
		createEReference(cityModelEClass, CITY_MODEL__MOSQUE);
		createEReference(cityModelEClass, CITY_MODEL__ROAD);
		createEReference(cityModelEClass, CITY_MODEL__PARK);
		createEReference(cityModelEClass, CITY_MODEL__SCHOOL);
		createEReference(cityModelEClass, CITY_MODEL__HOUSE);
		createEReference(cityModelEClass, CITY_MODEL__SECTOR);

		housingSchemeEClass = createEClass(HOUSING_SCHEME);
		createEAttribute(housingSchemeEClass, HOUSING_SCHEME__SCHEMENAME);
		createEAttribute(housingSchemeEClass, HOUSING_SCHEME__SCHEMEPOPU);
		createEAttribute(housingSchemeEClass, HOUSING_SCHEME__TOTALNOFHOUSES);
		createEAttribute(housingSchemeEClass, HOUSING_SCHEME__TOTALNOFROADS);
		createEAttribute(housingSchemeEClass, HOUSING_SCHEME__TOTALNOFSCHOOLS);
		createEAttribute(housingSchemeEClass, HOUSING_SCHEME__TOTALNOFPARKS);
		createEAttribute(housingSchemeEClass, HOUSING_SCHEME__TOTALNOFMOSQUES);
		createEAttribute(housingSchemeEClass, HOUSING_SCHEME__TOTALNOFHOSPITALS);
		createEAttribute(housingSchemeEClass, HOUSING_SCHEME__TOTALNOFGRAVEYARDS);
		createEAttribute(housingSchemeEClass, HOUSING_SCHEME__TOTALNOFOTHERS);
		createEAttribute(housingSchemeEClass, HOUSING_SCHEME__TOTALNOFSECTORS);
		createEReference(housingSchemeEClass, HOUSING_SCHEME__SECTOR);
		createEReference(housingSchemeEClass, HOUSING_SCHEME__GOVTRECOM);
		createEOperation(housingSchemeEClass, HOUSING_SCHEME___COMPARE);

		sectorEClass = createEClass(SECTOR);
		createEAttribute(sectorEClass, SECTOR__SECTORNAME);
		createEAttribute(sectorEClass, SECTOR__SECTORPOPU);
		createEAttribute(sectorEClass, SECTOR__NOFHOUSES);
		createEAttribute(sectorEClass, SECTOR__NOFROADS);
		createEAttribute(sectorEClass, SECTOR__NOFSCHOOLS);
		createEAttribute(sectorEClass, SECTOR__NOFPARKS);
		createEAttribute(sectorEClass, SECTOR__NOFMOSQUES);
		createEAttribute(sectorEClass, SECTOR__NOFHOSPITALS);
		createEAttribute(sectorEClass, SECTOR__NOFGRAVEYARDS);
		createEAttribute(sectorEClass, SECTOR__NOFOTHERS);
		createEReference(sectorEClass, SECTOR__SCHOOL);
		createEReference(sectorEClass, SECTOR__PARK);
		createEReference(sectorEClass, SECTOR__MOSQUE);
		createEReference(sectorEClass, SECTOR__OTHER);
		createEReference(sectorEClass, SECTOR__GRAVEYARD);
		createEReference(sectorEClass, SECTOR__HOSPITAL);
		createEReference(sectorEClass, SECTOR__HOUSE);
		createEReference(sectorEClass, SECTOR__ROAD);
		createEReference(sectorEClass, SECTOR__GOVTRECOM);
		createEOperation(sectorEClass, SECTOR___COMPARE);

		schoolEClass = createEClass(SCHOOL);
		createEAttribute(schoolEClass, SCHOOL__SCHOOLNAME);
		createEAttribute(schoolEClass, SCHOOL__SCHOOLCAPACITY);

		parkEClass = createEClass(PARK);
		createEAttribute(parkEClass, PARK__PARKNAME);
		createEAttribute(parkEClass, PARK__PARKCAPACITY);

		mosqueEClass = createEClass(MOSQUE);
		createEAttribute(mosqueEClass, MOSQUE__MOSQUENAME);
		createEAttribute(mosqueEClass, MOSQUE__MOSQUECAPACITY);

		hospitalEClass = createEClass(HOSPITAL);
		createEAttribute(hospitalEClass, HOSPITAL__HOSPITALNAME);
		createEAttribute(hospitalEClass, HOSPITAL__NOFBEDS);

		graveyardEClass = createEClass(GRAVEYARD);
		createEAttribute(graveyardEClass, GRAVEYARD__GRAVEYARDNAME);
		createEAttribute(graveyardEClass, GRAVEYARD__GRAVEYARDCAPACITY);

		otherEClass = createEClass(OTHER);
		createEAttribute(otherEClass, OTHER__OTHERNAME);
		createEAttribute(otherEClass, OTHER__OTHERCAPACITY);

		houseEClass = createEClass(HOUSE);
		createEAttribute(houseEClass, HOUSE__HOUSENBR);
		createEAttribute(houseEClass, HOUSE__STREETNBR);
		createEAttribute(houseEClass, HOUSE__NOFPEOPLE);

		roadEClass = createEClass(ROAD);
		createEAttribute(roadEClass, ROAD__ROADNAME);

		mainRoadEClass = createEClass(MAIN_ROAD);

		streetRoadEClass = createEClass(STREET_ROAD);

		serviceRoadEClass = createEClass(SERVICE_ROAD);

		govtRecomEClass = createEClass(GOVT_RECOM);
		createEAttribute(govtRecomEClass, GOVT_RECOM__SCHEME_POPU_CONTROL);
		createEAttribute(govtRecomEClass, GOVT_RECOM__SECTOR_POPU_CONTROL);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		mainRoadEClass.getESuperTypes().add(this.getRoad());
		streetRoadEClass.getESuperTypes().add(this.getRoad());
		serviceRoadEClass.getESuperTypes().add(this.getRoad());

		// Initialize classes, features, and operations; add parameters
		initEClass(cityModelEClass, CityModel.class, "CityModel", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCityModel_Cityname(), ecorePackage.getEString(), "cityname", null, 0, 1, CityModel.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCityModel_Housingscheme(), this.getHousingScheme(), null, "housingscheme", null, 0, -1,
				CityModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCityModel_Govtrecom(), this.getGovtRecom(), null, "govtrecom", null, 1, 1, CityModel.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCityModel_Hospital(), this.getHospital(), null, "hospital", null, 0, -1, CityModel.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCityModel_Graveyard(), this.getGraveyard(), null, "graveyard", null, 0, -1, CityModel.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCityModel_Other(), this.getOther(), null, "other", null, 0, -1, CityModel.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCityModel_Mosque(), this.getMosque(), null, "mosque", null, 0, -1, CityModel.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCityModel_Road(), this.getRoad(), null, "road", null, 0, -1, CityModel.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getCityModel_Park(), this.getPark(), null, "park", null, 0, -1, CityModel.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getCityModel_School(), this.getSchool(), null, "school", null, 0, -1, CityModel.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCityModel_House(), this.getHouse(), null, "house", null, 0, -1, CityModel.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCityModel_Sector(), this.getSector(), null, "sector", null, 0, -1, CityModel.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(housingSchemeEClass, HousingScheme.class, "HousingScheme", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getHousingScheme_Schemename(), ecorePackage.getEString(), "schemename", null, 0, 1,
				HousingScheme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getHousingScheme_Schemepopu(), ecorePackage.getEInt(), "schemepopu", null, 1, 1,
				HousingScheme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getHousingScheme_Totalnofhouses(), ecorePackage.getEInt(), "totalnofhouses", null, 1, 1,
				HousingScheme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getHousingScheme_Totalnofroads(), ecorePackage.getEInt(), "totalnofroads", null, 1, 1,
				HousingScheme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getHousingScheme_Totalnofschools(), ecorePackage.getEInt(), "totalnofschools", null, 1, 1,
				HousingScheme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getHousingScheme_Totalnofparks(), ecorePackage.getEInt(), "totalnofparks", null, 1, 1,
				HousingScheme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getHousingScheme_Totalnofmosques(), ecorePackage.getEInt(), "totalnofmosques", null, 1, 1,
				HousingScheme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getHousingScheme_Totalnofhospitals(), ecorePackage.getEInt(), "totalnofhospitals", null, 1, 1,
				HousingScheme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getHousingScheme_Totalnofgraveyards(), ecorePackage.getEInt(), "totalnofgraveyards", null, 1, 1,
				HousingScheme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getHousingScheme_Totalnofothers(), ecorePackage.getEInt(), "totalnofothers", null, 1, 1,
				HousingScheme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getHousingScheme_Totalnofsectors(), ecorePackage.getEInt(), "totalnofsectors", null, 1, 1,
				HousingScheme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getHousingScheme_Sector(), this.getSector(), null, "sector", null, 0, -1, HousingScheme.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHousingScheme_Govtrecom(), this.getGovtRecom(), null, "govtrecom", null, 1, 1,
				HousingScheme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getHousingScheme__Compare(), ecorePackage.getEBoolean(), "Compare", 1, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(sectorEClass, Sector.class, "Sector", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSector_Sectorname(), ecorePackage.getEString(), "sectorname", null, 0, 1, Sector.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSector_Sectorpopu(), ecorePackage.getEInt(), "sectorpopu", null, 1, 1, Sector.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSector_Nofhouses(), ecorePackage.getEInt(), "nofhouses", null, 1, 1, Sector.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSector_Nofroads(), ecorePackage.getEInt(), "nofroads", null, 1, 1, Sector.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSector_Nofschools(), ecorePackage.getEInt(), "nofschools", null, 1, 1, Sector.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSector_Nofparks(), ecorePackage.getEInt(), "nofparks", null, 1, 1, Sector.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSector_Nofmosques(), ecorePackage.getEInt(), "nofmosques", null, 1, 1, Sector.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSector_Nofhospitals(), ecorePackage.getEInt(), "nofhospitals", null, 1, 1, Sector.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSector_Nofgraveyards(), ecorePackage.getEInt(), "nofgraveyards", null, 1, 1, Sector.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSector_Nofothers(), ecorePackage.getEInt(), "nofothers", null, 1, 1, Sector.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSector_School(), this.getSchool(), null, "school", null, 0, -1, Sector.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getSector_Park(), this.getPark(), null, "park", null, 0, -1, Sector.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getSector_Mosque(), this.getMosque(), null, "mosque", null, 0, -1, Sector.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getSector_Other(), this.getOther(), null, "other", null, 0, -1, Sector.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getSector_Graveyard(), this.getGraveyard(), null, "graveyard", null, 0, -1, Sector.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSector_Hospital(), this.getHospital(), null, "hospital", null, 0, -1, Sector.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSector_House(), this.getHouse(), null, "house", null, 0, -1, Sector.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getSector_Road(), this.getRoad(), null, "road", null, 0, -1, Sector.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getSector_Govtrecom(), this.getGovtRecom(), null, "govtrecom", null, 1, 1, Sector.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getSector__Compare(), ecorePackage.getEBoolean(), "Compare", 1, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(schoolEClass, School.class, "School", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSchool_Schoolname(), ecorePackage.getEString(), "schoolname", null, 0, 1, School.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSchool_Schoolcapacity(), ecorePackage.getEInt(), "schoolcapacity", null, 1, 1, School.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(parkEClass, Park.class, "Park", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPark_Parkname(), ecorePackage.getEString(), "parkname", null, 0, 1, Park.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPark_Parkcapacity(), ecorePackage.getEInt(), "parkcapacity", null, 1, 1, Park.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(mosqueEClass, Mosque.class, "Mosque", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMosque_Mosquename(), ecorePackage.getEString(), "mosquename", null, 0, 1, Mosque.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMosque_Mosquecapacity(), ecorePackage.getEInt(), "mosquecapacity", null, 1, 1, Mosque.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(hospitalEClass, Hospital.class, "Hospital", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getHospital_Hospitalname(), ecorePackage.getEString(), "hospitalname", null, 0, 1,
				Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getHospital_Nofbeds(), ecorePackage.getEInt(), "nofbeds", null, 1, 1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(graveyardEClass, Graveyard.class, "Graveyard", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getGraveyard_Graveyardname(), ecorePackage.getEString(), "graveyardname", null, 0, 1,
				Graveyard.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getGraveyard_Graveyardcapacity(), ecorePackage.getEInt(), "graveyardcapacity", null, 1, 1,
				Graveyard.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(otherEClass, Other.class, "Other", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getOther_Othername(), ecorePackage.getEString(), "othername", null, 0, 1, Other.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getOther_Othercapacity(), ecorePackage.getEInt(), "othercapacity", null, 1, 1, Other.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(houseEClass, House.class, "House", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getHouse_Housenbr(), ecorePackage.getEInt(), "housenbr", null, 1, 1, House.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getHouse_Streetnbr(), ecorePackage.getEInt(), "streetnbr", null, 1, 1, House.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getHouse_Nofpeople(), ecorePackage.getEInt(), "nofpeople", "5", 1, 1, House.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(roadEClass, Road.class, "Road", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRoad_Roadname(), ecorePackage.getEString(), "roadname", null, 0, 1, Road.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(mainRoadEClass, MainRoad.class, "MainRoad", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(streetRoadEClass, StreetRoad.class, "StreetRoad", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(serviceRoadEClass, ServiceRoad.class, "ServiceRoad", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(govtRecomEClass, GovtRecom.class, "GovtRecom", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getGovtRecom_SchemePopuControl(), ecorePackage.getEInt(), "SchemePopuControl", null, 1, 1,
				GovtRecom.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getGovtRecom_SectorPopuControl(), ecorePackage.getEInt(), "SectorPopuControl", null, 1, 1,
				GovtRecom.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/OCL/Import
		createImportAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot
		createPivotAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/OCL/Import</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createImportAnnotations() {
		String source = "http://www.eclipse.org/OCL/Import";
		addAnnotation(this, source, new String[] { "ecore", "http://www.eclipse.org/emf/2002/Ecore" });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore";
		addAnnotation(this, source,
				new String[] { "invocationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
						"settingDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "validationDelegates",
						"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot" });
		addAnnotation(housingSchemeEClass, source, new String[] { "constraints", "HousingSchemePopulationControl" });
		addAnnotation(sectorEClass, source, new String[] { "constraints", "SectorPopulationControl" });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createPivotAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot";
		addAnnotation(housingSchemeEClass, source,
				new String[] { "HousingSchemePopulationControl", "schemepopu < govtrecom.SchemePopuControl" });
		addAnnotation(getHousingScheme__Compare(), source,
				new String[] { "body", "schemepopu < govtrecom.SchemePopuControl" });
		addAnnotation(getHousingScheme_Schemepopu(), source,
				new String[] { "derivation", "self.sector.sectorpopu -> sum()" });
		addAnnotation(getHousingScheme_Totalnofhouses(), source,
				new String[] { "derivation", "self.sector.nofhouses -> sum()" });
		addAnnotation(getHousingScheme_Totalnofroads(), source,
				new String[] { "derivation", "self.sector.nofroads -> sum()" });
		addAnnotation(getHousingScheme_Totalnofschools(), source,
				new String[] { "derivation", "self.sector.nofschools -> sum()" });
		addAnnotation(getHousingScheme_Totalnofparks(), source,
				new String[] { "derivation", "self.sector.nofparks -> sum()" });
		addAnnotation(getHousingScheme_Totalnofmosques(), source,
				new String[] { "derivation", "self.sector.nofmosques -> sum()" });
		addAnnotation(getHousingScheme_Totalnofhospitals(), source,
				new String[] { "derivation", "self.sector.nofhospitals -> sum()" });
		addAnnotation(getHousingScheme_Totalnofgraveyards(), source,
				new String[] { "derivation", "self.sector.nofgraveyards -> sum()" });
		addAnnotation(getHousingScheme_Totalnofothers(), source,
				new String[] { "derivation", "self.sector.nofothers -> sum()" });
		addAnnotation(getHousingScheme_Totalnofsectors(), source,
				new String[] { "derivation", "self.sector -> size()" });
		addAnnotation(sectorEClass, source,
				new String[] { "SectorPopulationControl", "sectorpopu < govtrecom.SectorPopuControl" });
		addAnnotation(getSector__Compare(), source,
				new String[] { "body", "sectorpopu < govtrecom.SectorPopuControl" });
		addAnnotation(getSector_Sectorpopu(), source, new String[] { "derivation", "self.house.nofpeople -> sum()" });
		addAnnotation(getSector_Nofhouses(), source, new String[] { "derivation", "self.house -> size()" });
		addAnnotation(getSector_Nofroads(), source, new String[] { "derivation", "self.road -> size()" });
		addAnnotation(getSector_Nofschools(), source, new String[] { "derivation", "self.school -> size()" });
		addAnnotation(getSector_Nofparks(), source, new String[] { "derivation", "self.park -> size()" });
		addAnnotation(getSector_Nofmosques(), source, new String[] { "derivation", "self.mosque -> size()" });
		addAnnotation(getSector_Nofhospitals(), source, new String[] { "derivation", "self.hospital -> size()" });
		addAnnotation(getSector_Nofgraveyards(), source, new String[] { "derivation", "self.graveyard -> size()" });
		addAnnotation(getSector_Nofothers(), source, new String[] { "derivation", "self.other -> size()" });
	}

} //CensusPackageImpl

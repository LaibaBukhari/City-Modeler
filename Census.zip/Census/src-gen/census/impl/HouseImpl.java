/**
 */
package census.impl;

import census.CensusPackage;
import census.House;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>House</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link census.impl.HouseImpl#getHousenbr <em>Housenbr</em>}</li>
 *   <li>{@link census.impl.HouseImpl#getStreetnbr <em>Streetnbr</em>}</li>
 *   <li>{@link census.impl.HouseImpl#getNofpeople <em>Nofpeople</em>}</li>
 * </ul>
 *
 * @generated
 */
public class HouseImpl extends MinimalEObjectImpl.Container implements House {
	/**
	 * The default value of the '{@link #getHousenbr() <em>Housenbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHousenbr()
	 * @generated
	 * @ordered
	 */
	protected static final int HOUSENBR_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getHousenbr() <em>Housenbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHousenbr()
	 * @generated
	 * @ordered
	 */
	protected int housenbr = HOUSENBR_EDEFAULT;

	/**
	 * The default value of the '{@link #getStreetnbr() <em>Streetnbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStreetnbr()
	 * @generated
	 * @ordered
	 */
	protected static final int STREETNBR_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getStreetnbr() <em>Streetnbr</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStreetnbr()
	 * @generated
	 * @ordered
	 */
	protected int streetnbr = STREETNBR_EDEFAULT;

	/**
	 * The default value of the '{@link #getNofpeople() <em>Nofpeople</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNofpeople()
	 * @generated
	 * @ordered
	 */
	protected static final int NOFPEOPLE_EDEFAULT = 5;

	/**
	 * The cached value of the '{@link #getNofpeople() <em>Nofpeople</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNofpeople()
	 * @generated
	 * @ordered
	 */
	protected int nofpeople = NOFPEOPLE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HouseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CensusPackage.Literals.HOUSE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getHousenbr() {
		return housenbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHousenbr(int newHousenbr) {
		int oldHousenbr = housenbr;
		housenbr = newHousenbr;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.HOUSE__HOUSENBR, oldHousenbr,
					housenbr));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getStreetnbr() {
		return streetnbr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStreetnbr(int newStreetnbr) {
		int oldStreetnbr = streetnbr;
		streetnbr = newStreetnbr;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.HOUSE__STREETNBR, oldStreetnbr,
					streetnbr));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNofpeople() {
		return nofpeople;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNofpeople(int newNofpeople) {
		int oldNofpeople = nofpeople;
		nofpeople = newNofpeople;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.HOUSE__NOFPEOPLE, oldNofpeople,
					nofpeople));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CensusPackage.HOUSE__HOUSENBR:
			return getHousenbr();
		case CensusPackage.HOUSE__STREETNBR:
			return getStreetnbr();
		case CensusPackage.HOUSE__NOFPEOPLE:
			return getNofpeople();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CensusPackage.HOUSE__HOUSENBR:
			setHousenbr((Integer) newValue);
			return;
		case CensusPackage.HOUSE__STREETNBR:
			setStreetnbr((Integer) newValue);
			return;
		case CensusPackage.HOUSE__NOFPEOPLE:
			setNofpeople((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CensusPackage.HOUSE__HOUSENBR:
			setHousenbr(HOUSENBR_EDEFAULT);
			return;
		case CensusPackage.HOUSE__STREETNBR:
			setStreetnbr(STREETNBR_EDEFAULT);
			return;
		case CensusPackage.HOUSE__NOFPEOPLE:
			setNofpeople(NOFPEOPLE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CensusPackage.HOUSE__HOUSENBR:
			return housenbr != HOUSENBR_EDEFAULT;
		case CensusPackage.HOUSE__STREETNBR:
			return streetnbr != STREETNBR_EDEFAULT;
		case CensusPackage.HOUSE__NOFPEOPLE:
			return nofpeople != NOFPEOPLE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (housenbr: ");
		result.append(housenbr);
		result.append(", streetnbr: ");
		result.append(streetnbr);
		result.append(", nofpeople: ");
		result.append(nofpeople);
		result.append(')');
		return result.toString();
	}

} //HouseImpl

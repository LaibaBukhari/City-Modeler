/**
 */
package census.impl;

import census.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CensusFactoryImpl extends EFactoryImpl implements CensusFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static CensusFactory init() {
		try {
			CensusFactory theCensusFactory = (CensusFactory) EPackage.Registry.INSTANCE
					.getEFactory(CensusPackage.eNS_URI);
			if (theCensusFactory != null) {
				return theCensusFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new CensusFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CensusFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case CensusPackage.CITY_MODEL:
			return createCityModel();
		case CensusPackage.HOUSING_SCHEME:
			return createHousingScheme();
		case CensusPackage.SECTOR:
			return createSector();
		case CensusPackage.SCHOOL:
			return createSchool();
		case CensusPackage.PARK:
			return createPark();
		case CensusPackage.MOSQUE:
			return createMosque();
		case CensusPackage.HOSPITAL:
			return createHospital();
		case CensusPackage.GRAVEYARD:
			return createGraveyard();
		case CensusPackage.OTHER:
			return createOther();
		case CensusPackage.HOUSE:
			return createHouse();
		case CensusPackage.MAIN_ROAD:
			return createMainRoad();
		case CensusPackage.STREET_ROAD:
			return createStreetRoad();
		case CensusPackage.SERVICE_ROAD:
			return createServiceRoad();
		case CensusPackage.GOVT_RECOM:
			return createGovtRecom();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CityModel createCityModel() {
		CityModelImpl cityModel = new CityModelImpl();
		return cityModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HousingScheme createHousingScheme() {
		HousingSchemeImpl housingScheme = new HousingSchemeImpl();
		return housingScheme;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Sector createSector() {
		SectorImpl sector = new SectorImpl();
		return sector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public School createSchool() {
		SchoolImpl school = new SchoolImpl();
		return school;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Park createPark() {
		ParkImpl park = new ParkImpl();
		return park;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Mosque createMosque() {
		MosqueImpl mosque = new MosqueImpl();
		return mosque;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Hospital createHospital() {
		HospitalImpl hospital = new HospitalImpl();
		return hospital;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Graveyard createGraveyard() {
		GraveyardImpl graveyard = new GraveyardImpl();
		return graveyard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Other createOther() {
		OtherImpl other = new OtherImpl();
		return other;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public House createHouse() {
		HouseImpl house = new HouseImpl();
		return house;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MainRoad createMainRoad() {
		MainRoadImpl mainRoad = new MainRoadImpl();
		return mainRoad;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StreetRoad createStreetRoad() {
		StreetRoadImpl streetRoad = new StreetRoadImpl();
		return streetRoad;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ServiceRoad createServiceRoad() {
		ServiceRoadImpl serviceRoad = new ServiceRoadImpl();
		return serviceRoad;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GovtRecom createGovtRecom() {
		GovtRecomImpl govtRecom = new GovtRecomImpl();
		return govtRecom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CensusPackage getCensusPackage() {
		return (CensusPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static CensusPackage getPackage() {
		return CensusPackage.eINSTANCE;
	}

} //CensusFactoryImpl

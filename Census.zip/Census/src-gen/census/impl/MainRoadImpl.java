/**
 */
package census.impl;

import census.CensusPackage;
import census.MainRoad;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Main Road</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class MainRoadImpl extends RoadImpl implements MainRoad {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MainRoadImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CensusPackage.Literals.MAIN_ROAD;
	}

} //MainRoadImpl

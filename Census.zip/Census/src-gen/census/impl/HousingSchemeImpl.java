/**
 */
package census.impl;

import census.CensusPackage;
import census.GovtRecom;
import census.HousingScheme;
import census.Sector;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.WrappedException;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Housing Scheme</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link census.impl.HousingSchemeImpl#getSchemename <em>Schemename</em>}</li>
 *   <li>{@link census.impl.HousingSchemeImpl#getSchemepopu <em>Schemepopu</em>}</li>
 *   <li>{@link census.impl.HousingSchemeImpl#getTotalnofhouses <em>Totalnofhouses</em>}</li>
 *   <li>{@link census.impl.HousingSchemeImpl#getTotalnofroads <em>Totalnofroads</em>}</li>
 *   <li>{@link census.impl.HousingSchemeImpl#getTotalnofschools <em>Totalnofschools</em>}</li>
 *   <li>{@link census.impl.HousingSchemeImpl#getTotalnofparks <em>Totalnofparks</em>}</li>
 *   <li>{@link census.impl.HousingSchemeImpl#getTotalnofmosques <em>Totalnofmosques</em>}</li>
 *   <li>{@link census.impl.HousingSchemeImpl#getTotalnofhospitals <em>Totalnofhospitals</em>}</li>
 *   <li>{@link census.impl.HousingSchemeImpl#getTotalnofgraveyards <em>Totalnofgraveyards</em>}</li>
 *   <li>{@link census.impl.HousingSchemeImpl#getTotalnofothers <em>Totalnofothers</em>}</li>
 *   <li>{@link census.impl.HousingSchemeImpl#getTotalnofsectors <em>Totalnofsectors</em>}</li>
 *   <li>{@link census.impl.HousingSchemeImpl#getSector <em>Sector</em>}</li>
 *   <li>{@link census.impl.HousingSchemeImpl#getGovtrecom <em>Govtrecom</em>}</li>
 * </ul>
 *
 * @generated
 */
public class HousingSchemeImpl extends MinimalEObjectImpl.Container implements HousingScheme {
	/**
	 * The default value of the '{@link #getSchemename() <em>Schemename</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSchemename()
	 * @generated
	 * @ordered
	 */
	protected static final String SCHEMENAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSchemename() <em>Schemename</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSchemename()
	 * @generated
	 * @ordered
	 */
	protected String schemename = SCHEMENAME_EDEFAULT;

	/**
	 * The cached setting delegate for the '{@link #getSchemepopu() <em>Schemepopu</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSchemepopu()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate SCHEMEPOPU__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.HOUSING_SCHEME__SCHEMEPOPU)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getTotalnofhouses() <em>Totalnofhouses</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalnofhouses()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate TOTALNOFHOUSES__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.HOUSING_SCHEME__TOTALNOFHOUSES)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getTotalnofroads() <em>Totalnofroads</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalnofroads()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate TOTALNOFROADS__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.HOUSING_SCHEME__TOTALNOFROADS)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getTotalnofschools() <em>Totalnofschools</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalnofschools()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate TOTALNOFSCHOOLS__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.HOUSING_SCHEME__TOTALNOFSCHOOLS)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getTotalnofparks() <em>Totalnofparks</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalnofparks()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate TOTALNOFPARKS__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.HOUSING_SCHEME__TOTALNOFPARKS)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getTotalnofmosques() <em>Totalnofmosques</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalnofmosques()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate TOTALNOFMOSQUES__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.HOUSING_SCHEME__TOTALNOFMOSQUES)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getTotalnofhospitals() <em>Totalnofhospitals</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalnofhospitals()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate TOTALNOFHOSPITALS__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.HOUSING_SCHEME__TOTALNOFHOSPITALS)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getTotalnofgraveyards() <em>Totalnofgraveyards</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalnofgraveyards()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate TOTALNOFGRAVEYARDS__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.HOUSING_SCHEME__TOTALNOFGRAVEYARDS)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getTotalnofothers() <em>Totalnofothers</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalnofothers()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate TOTALNOFOTHERS__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.HOUSING_SCHEME__TOTALNOFOTHERS)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getTotalnofsectors() <em>Totalnofsectors</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalnofsectors()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate TOTALNOFSECTORS__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.HOUSING_SCHEME__TOTALNOFSECTORS)
			.getSettingDelegate();

	/**
	 * The cached value of the '{@link #getSector() <em>Sector</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSector()
	 * @generated
	 * @ordered
	 */
	protected EList<Sector> sector;

	/**
	 * The cached value of the '{@link #getGovtrecom() <em>Govtrecom</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGovtrecom()
	 * @generated
	 * @ordered
	 */
	protected GovtRecom govtrecom;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HousingSchemeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CensusPackage.Literals.HOUSING_SCHEME;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSchemename() {
		return schemename;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSchemename(String newSchemename) {
		String oldSchemename = schemename;
		schemename = newSchemename;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.HOUSING_SCHEME__SCHEMENAME,
					oldSchemename, schemename));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getSchemepopu() {
		return (Integer) SCHEMEPOPU__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSchemepopu(int newSchemepopu) {
		SCHEMEPOPU__ESETTING_DELEGATE.dynamicSet(this, null, 0, newSchemepopu);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTotalnofhouses() {
		return (Integer) TOTALNOFHOUSES__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalnofhouses(int newTotalnofhouses) {
		TOTALNOFHOUSES__ESETTING_DELEGATE.dynamicSet(this, null, 0, newTotalnofhouses);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTotalnofroads() {
		return (Integer) TOTALNOFROADS__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalnofroads(int newTotalnofroads) {
		TOTALNOFROADS__ESETTING_DELEGATE.dynamicSet(this, null, 0, newTotalnofroads);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTotalnofschools() {
		return (Integer) TOTALNOFSCHOOLS__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalnofschools(int newTotalnofschools) {
		TOTALNOFSCHOOLS__ESETTING_DELEGATE.dynamicSet(this, null, 0, newTotalnofschools);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTotalnofparks() {
		return (Integer) TOTALNOFPARKS__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalnofparks(int newTotalnofparks) {
		TOTALNOFPARKS__ESETTING_DELEGATE.dynamicSet(this, null, 0, newTotalnofparks);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTotalnofmosques() {
		return (Integer) TOTALNOFMOSQUES__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalnofmosques(int newTotalnofmosques) {
		TOTALNOFMOSQUES__ESETTING_DELEGATE.dynamicSet(this, null, 0, newTotalnofmosques);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTotalnofhospitals() {
		return (Integer) TOTALNOFHOSPITALS__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalnofhospitals(int newTotalnofhospitals) {
		TOTALNOFHOSPITALS__ESETTING_DELEGATE.dynamicSet(this, null, 0, newTotalnofhospitals);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTotalnofgraveyards() {
		return (Integer) TOTALNOFGRAVEYARDS__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalnofgraveyards(int newTotalnofgraveyards) {
		TOTALNOFGRAVEYARDS__ESETTING_DELEGATE.dynamicSet(this, null, 0, newTotalnofgraveyards);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTotalnofothers() {
		return (Integer) TOTALNOFOTHERS__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalnofothers(int newTotalnofothers) {
		TOTALNOFOTHERS__ESETTING_DELEGATE.dynamicSet(this, null, 0, newTotalnofothers);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTotalnofsectors() {
		return (Integer) TOTALNOFSECTORS__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalnofsectors(int newTotalnofsectors) {
		TOTALNOFSECTORS__ESETTING_DELEGATE.dynamicSet(this, null, 0, newTotalnofsectors);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Sector> getSector() {
		if (sector == null) {
			sector = new EObjectContainmentEList<Sector>(Sector.class, this, CensusPackage.HOUSING_SCHEME__SECTOR);
		}
		return sector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GovtRecom getGovtrecom() {
		if (govtrecom != null && govtrecom.eIsProxy()) {
			InternalEObject oldGovtrecom = (InternalEObject) govtrecom;
			govtrecom = (GovtRecom) eResolveProxy(oldGovtrecom);
			if (govtrecom != oldGovtrecom) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CensusPackage.HOUSING_SCHEME__GOVTRECOM,
							oldGovtrecom, govtrecom));
			}
		}
		return govtrecom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GovtRecom basicGetGovtrecom() {
		return govtrecom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGovtrecom(GovtRecom newGovtrecom) {
		GovtRecom oldGovtrecom = govtrecom;
		govtrecom = newGovtrecom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.HOUSING_SCHEME__GOVTRECOM, oldGovtrecom,
					govtrecom));
	}

	/**
	 * The cached invocation delegate for the '{@link #Compare() <em>Compare</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #Compare()
	 * @generated
	 * @ordered
	 */
	protected static final EOperation.Internal.InvocationDelegate COMPARE__EINVOCATION_DELEGATE = ((EOperation.Internal) CensusPackage.Literals.HOUSING_SCHEME___COMPARE)
			.getInvocationDelegate();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean Compare() {
		try {
			return (Boolean) COMPARE__EINVOCATION_DELEGATE.dynamicInvoke(this, null);
		} catch (InvocationTargetException ite) {
			throw new WrappedException(ite);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case CensusPackage.HOUSING_SCHEME__SECTOR:
			return ((InternalEList<?>) getSector()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CensusPackage.HOUSING_SCHEME__SCHEMENAME:
			return getSchemename();
		case CensusPackage.HOUSING_SCHEME__SCHEMEPOPU:
			return getSchemepopu();
		case CensusPackage.HOUSING_SCHEME__TOTALNOFHOUSES:
			return getTotalnofhouses();
		case CensusPackage.HOUSING_SCHEME__TOTALNOFROADS:
			return getTotalnofroads();
		case CensusPackage.HOUSING_SCHEME__TOTALNOFSCHOOLS:
			return getTotalnofschools();
		case CensusPackage.HOUSING_SCHEME__TOTALNOFPARKS:
			return getTotalnofparks();
		case CensusPackage.HOUSING_SCHEME__TOTALNOFMOSQUES:
			return getTotalnofmosques();
		case CensusPackage.HOUSING_SCHEME__TOTALNOFHOSPITALS:
			return getTotalnofhospitals();
		case CensusPackage.HOUSING_SCHEME__TOTALNOFGRAVEYARDS:
			return getTotalnofgraveyards();
		case CensusPackage.HOUSING_SCHEME__TOTALNOFOTHERS:
			return getTotalnofothers();
		case CensusPackage.HOUSING_SCHEME__TOTALNOFSECTORS:
			return getTotalnofsectors();
		case CensusPackage.HOUSING_SCHEME__SECTOR:
			return getSector();
		case CensusPackage.HOUSING_SCHEME__GOVTRECOM:
			if (resolve)
				return getGovtrecom();
			return basicGetGovtrecom();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CensusPackage.HOUSING_SCHEME__SCHEMENAME:
			setSchemename((String) newValue);
			return;
		case CensusPackage.HOUSING_SCHEME__SCHEMEPOPU:
			setSchemepopu((Integer) newValue);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFHOUSES:
			setTotalnofhouses((Integer) newValue);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFROADS:
			setTotalnofroads((Integer) newValue);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFSCHOOLS:
			setTotalnofschools((Integer) newValue);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFPARKS:
			setTotalnofparks((Integer) newValue);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFMOSQUES:
			setTotalnofmosques((Integer) newValue);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFHOSPITALS:
			setTotalnofhospitals((Integer) newValue);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFGRAVEYARDS:
			setTotalnofgraveyards((Integer) newValue);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFOTHERS:
			setTotalnofothers((Integer) newValue);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFSECTORS:
			setTotalnofsectors((Integer) newValue);
			return;
		case CensusPackage.HOUSING_SCHEME__SECTOR:
			getSector().clear();
			getSector().addAll((Collection<? extends Sector>) newValue);
			return;
		case CensusPackage.HOUSING_SCHEME__GOVTRECOM:
			setGovtrecom((GovtRecom) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CensusPackage.HOUSING_SCHEME__SCHEMENAME:
			setSchemename(SCHEMENAME_EDEFAULT);
			return;
		case CensusPackage.HOUSING_SCHEME__SCHEMEPOPU:
			SCHEMEPOPU__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFHOUSES:
			TOTALNOFHOUSES__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFROADS:
			TOTALNOFROADS__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFSCHOOLS:
			TOTALNOFSCHOOLS__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFPARKS:
			TOTALNOFPARKS__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFMOSQUES:
			TOTALNOFMOSQUES__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFHOSPITALS:
			TOTALNOFHOSPITALS__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFGRAVEYARDS:
			TOTALNOFGRAVEYARDS__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFOTHERS:
			TOTALNOFOTHERS__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.HOUSING_SCHEME__TOTALNOFSECTORS:
			TOTALNOFSECTORS__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.HOUSING_SCHEME__SECTOR:
			getSector().clear();
			return;
		case CensusPackage.HOUSING_SCHEME__GOVTRECOM:
			setGovtrecom((GovtRecom) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CensusPackage.HOUSING_SCHEME__SCHEMENAME:
			return SCHEMENAME_EDEFAULT == null ? schemename != null : !SCHEMENAME_EDEFAULT.equals(schemename);
		case CensusPackage.HOUSING_SCHEME__SCHEMEPOPU:
			return SCHEMEPOPU__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.HOUSING_SCHEME__TOTALNOFHOUSES:
			return TOTALNOFHOUSES__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.HOUSING_SCHEME__TOTALNOFROADS:
			return TOTALNOFROADS__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.HOUSING_SCHEME__TOTALNOFSCHOOLS:
			return TOTALNOFSCHOOLS__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.HOUSING_SCHEME__TOTALNOFPARKS:
			return TOTALNOFPARKS__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.HOUSING_SCHEME__TOTALNOFMOSQUES:
			return TOTALNOFMOSQUES__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.HOUSING_SCHEME__TOTALNOFHOSPITALS:
			return TOTALNOFHOSPITALS__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.HOUSING_SCHEME__TOTALNOFGRAVEYARDS:
			return TOTALNOFGRAVEYARDS__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.HOUSING_SCHEME__TOTALNOFOTHERS:
			return TOTALNOFOTHERS__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.HOUSING_SCHEME__TOTALNOFSECTORS:
			return TOTALNOFSECTORS__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.HOUSING_SCHEME__SECTOR:
			return sector != null && !sector.isEmpty();
		case CensusPackage.HOUSING_SCHEME__GOVTRECOM:
			return govtrecom != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case CensusPackage.HOUSING_SCHEME___COMPARE:
			return Compare();
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (schemename: ");
		result.append(schemename);
		result.append(')');
		return result.toString();
	}

} //HousingSchemeImpl

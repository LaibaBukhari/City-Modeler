/**
 */
package census.impl;

import census.CensusPackage;
import census.ServiceRoad;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Service Road</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ServiceRoadImpl extends RoadImpl implements ServiceRoad {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ServiceRoadImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CensusPackage.Literals.SERVICE_ROAD;
	}

} //ServiceRoadImpl

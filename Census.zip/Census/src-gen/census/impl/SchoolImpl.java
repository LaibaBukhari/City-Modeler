/**
 */
package census.impl;

import census.CensusPackage;
import census.School;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>School</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link census.impl.SchoolImpl#getSchoolname <em>Schoolname</em>}</li>
 *   <li>{@link census.impl.SchoolImpl#getSchoolcapacity <em>Schoolcapacity</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SchoolImpl extends MinimalEObjectImpl.Container implements School {
	/**
	 * The default value of the '{@link #getSchoolname() <em>Schoolname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSchoolname()
	 * @generated
	 * @ordered
	 */
	protected static final String SCHOOLNAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSchoolname() <em>Schoolname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSchoolname()
	 * @generated
	 * @ordered
	 */
	protected String schoolname = SCHOOLNAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getSchoolcapacity() <em>Schoolcapacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSchoolcapacity()
	 * @generated
	 * @ordered
	 */
	protected static final int SCHOOLCAPACITY_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getSchoolcapacity() <em>Schoolcapacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSchoolcapacity()
	 * @generated
	 * @ordered
	 */
	protected int schoolcapacity = SCHOOLCAPACITY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SchoolImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CensusPackage.Literals.SCHOOL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSchoolname() {
		return schoolname;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSchoolname(String newSchoolname) {
		String oldSchoolname = schoolname;
		schoolname = newSchoolname;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.SCHOOL__SCHOOLNAME, oldSchoolname,
					schoolname));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getSchoolcapacity() {
		return schoolcapacity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSchoolcapacity(int newSchoolcapacity) {
		int oldSchoolcapacity = schoolcapacity;
		schoolcapacity = newSchoolcapacity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.SCHOOL__SCHOOLCAPACITY,
					oldSchoolcapacity, schoolcapacity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CensusPackage.SCHOOL__SCHOOLNAME:
			return getSchoolname();
		case CensusPackage.SCHOOL__SCHOOLCAPACITY:
			return getSchoolcapacity();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CensusPackage.SCHOOL__SCHOOLNAME:
			setSchoolname((String) newValue);
			return;
		case CensusPackage.SCHOOL__SCHOOLCAPACITY:
			setSchoolcapacity((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CensusPackage.SCHOOL__SCHOOLNAME:
			setSchoolname(SCHOOLNAME_EDEFAULT);
			return;
		case CensusPackage.SCHOOL__SCHOOLCAPACITY:
			setSchoolcapacity(SCHOOLCAPACITY_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CensusPackage.SCHOOL__SCHOOLNAME:
			return SCHOOLNAME_EDEFAULT == null ? schoolname != null : !SCHOOLNAME_EDEFAULT.equals(schoolname);
		case CensusPackage.SCHOOL__SCHOOLCAPACITY:
			return schoolcapacity != SCHOOLCAPACITY_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (schoolname: ");
		result.append(schoolname);
		result.append(", schoolcapacity: ");
		result.append(schoolcapacity);
		result.append(')');
		return result.toString();
	}

} //SchoolImpl

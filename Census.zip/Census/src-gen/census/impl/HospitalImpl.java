/**
 */
package census.impl;

import census.CensusPackage;
import census.Hospital;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Hospital</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link census.impl.HospitalImpl#getHospitalname <em>Hospitalname</em>}</li>
 *   <li>{@link census.impl.HospitalImpl#getNofbeds <em>Nofbeds</em>}</li>
 * </ul>
 *
 * @generated
 */
public class HospitalImpl extends MinimalEObjectImpl.Container implements Hospital {
	/**
	 * The default value of the '{@link #getHospitalname() <em>Hospitalname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHospitalname()
	 * @generated
	 * @ordered
	 */
	protected static final String HOSPITALNAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getHospitalname() <em>Hospitalname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHospitalname()
	 * @generated
	 * @ordered
	 */
	protected String hospitalname = HOSPITALNAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNofbeds() <em>Nofbeds</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNofbeds()
	 * @generated
	 * @ordered
	 */
	protected static final int NOFBEDS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getNofbeds() <em>Nofbeds</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNofbeds()
	 * @generated
	 * @ordered
	 */
	protected int nofbeds = NOFBEDS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HospitalImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CensusPackage.Literals.HOSPITAL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getHospitalname() {
		return hospitalname;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHospitalname(String newHospitalname) {
		String oldHospitalname = hospitalname;
		hospitalname = newHospitalname;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.HOSPITAL__HOSPITALNAME, oldHospitalname,
					hospitalname));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNofbeds() {
		return nofbeds;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNofbeds(int newNofbeds) {
		int oldNofbeds = nofbeds;
		nofbeds = newNofbeds;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.HOSPITAL__NOFBEDS, oldNofbeds,
					nofbeds));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CensusPackage.HOSPITAL__HOSPITALNAME:
			return getHospitalname();
		case CensusPackage.HOSPITAL__NOFBEDS:
			return getNofbeds();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CensusPackage.HOSPITAL__HOSPITALNAME:
			setHospitalname((String) newValue);
			return;
		case CensusPackage.HOSPITAL__NOFBEDS:
			setNofbeds((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CensusPackage.HOSPITAL__HOSPITALNAME:
			setHospitalname(HOSPITALNAME_EDEFAULT);
			return;
		case CensusPackage.HOSPITAL__NOFBEDS:
			setNofbeds(NOFBEDS_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CensusPackage.HOSPITAL__HOSPITALNAME:
			return HOSPITALNAME_EDEFAULT == null ? hospitalname != null : !HOSPITALNAME_EDEFAULT.equals(hospitalname);
		case CensusPackage.HOSPITAL__NOFBEDS:
			return nofbeds != NOFBEDS_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (hospitalname: ");
		result.append(hospitalname);
		result.append(", nofbeds: ");
		result.append(nofbeds);
		result.append(')');
		return result.toString();
	}

} //HospitalImpl

/**
 */
package census.impl;

import census.CensusPackage;
import census.Other;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Other</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link census.impl.OtherImpl#getOthername <em>Othername</em>}</li>
 *   <li>{@link census.impl.OtherImpl#getOthercapacity <em>Othercapacity</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OtherImpl extends MinimalEObjectImpl.Container implements Other {
	/**
	 * The default value of the '{@link #getOthername() <em>Othername</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOthername()
	 * @generated
	 * @ordered
	 */
	protected static final String OTHERNAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOthername() <em>Othername</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOthername()
	 * @generated
	 * @ordered
	 */
	protected String othername = OTHERNAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getOthercapacity() <em>Othercapacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOthercapacity()
	 * @generated
	 * @ordered
	 */
	protected static final int OTHERCAPACITY_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getOthercapacity() <em>Othercapacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOthercapacity()
	 * @generated
	 * @ordered
	 */
	protected int othercapacity = OTHERCAPACITY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OtherImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CensusPackage.Literals.OTHER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOthername() {
		return othername;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOthername(String newOthername) {
		String oldOthername = othername;
		othername = newOthername;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.OTHER__OTHERNAME, oldOthername,
					othername));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getOthercapacity() {
		return othercapacity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOthercapacity(int newOthercapacity) {
		int oldOthercapacity = othercapacity;
		othercapacity = newOthercapacity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.OTHER__OTHERCAPACITY, oldOthercapacity,
					othercapacity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CensusPackage.OTHER__OTHERNAME:
			return getOthername();
		case CensusPackage.OTHER__OTHERCAPACITY:
			return getOthercapacity();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CensusPackage.OTHER__OTHERNAME:
			setOthername((String) newValue);
			return;
		case CensusPackage.OTHER__OTHERCAPACITY:
			setOthercapacity((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CensusPackage.OTHER__OTHERNAME:
			setOthername(OTHERNAME_EDEFAULT);
			return;
		case CensusPackage.OTHER__OTHERCAPACITY:
			setOthercapacity(OTHERCAPACITY_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CensusPackage.OTHER__OTHERNAME:
			return OTHERNAME_EDEFAULT == null ? othername != null : !OTHERNAME_EDEFAULT.equals(othername);
		case CensusPackage.OTHER__OTHERCAPACITY:
			return othercapacity != OTHERCAPACITY_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (othername: ");
		result.append(othername);
		result.append(", othercapacity: ");
		result.append(othercapacity);
		result.append(')');
		return result.toString();
	}

} //OtherImpl

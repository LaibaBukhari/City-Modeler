/**
 */
package census.impl;

import census.CensusPackage;
import census.Park;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Park</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link census.impl.ParkImpl#getParkname <em>Parkname</em>}</li>
 *   <li>{@link census.impl.ParkImpl#getParkcapacity <em>Parkcapacity</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ParkImpl extends MinimalEObjectImpl.Container implements Park {
	/**
	 * The default value of the '{@link #getParkname() <em>Parkname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParkname()
	 * @generated
	 * @ordered
	 */
	protected static final String PARKNAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getParkname() <em>Parkname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParkname()
	 * @generated
	 * @ordered
	 */
	protected String parkname = PARKNAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getParkcapacity() <em>Parkcapacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParkcapacity()
	 * @generated
	 * @ordered
	 */
	protected static final int PARKCAPACITY_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getParkcapacity() <em>Parkcapacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParkcapacity()
	 * @generated
	 * @ordered
	 */
	protected int parkcapacity = PARKCAPACITY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ParkImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CensusPackage.Literals.PARK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getParkname() {
		return parkname;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setParkname(String newParkname) {
		String oldParkname = parkname;
		parkname = newParkname;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.PARK__PARKNAME, oldParkname, parkname));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getParkcapacity() {
		return parkcapacity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setParkcapacity(int newParkcapacity) {
		int oldParkcapacity = parkcapacity;
		parkcapacity = newParkcapacity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.PARK__PARKCAPACITY, oldParkcapacity,
					parkcapacity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CensusPackage.PARK__PARKNAME:
			return getParkname();
		case CensusPackage.PARK__PARKCAPACITY:
			return getParkcapacity();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CensusPackage.PARK__PARKNAME:
			setParkname((String) newValue);
			return;
		case CensusPackage.PARK__PARKCAPACITY:
			setParkcapacity((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CensusPackage.PARK__PARKNAME:
			setParkname(PARKNAME_EDEFAULT);
			return;
		case CensusPackage.PARK__PARKCAPACITY:
			setParkcapacity(PARKCAPACITY_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CensusPackage.PARK__PARKNAME:
			return PARKNAME_EDEFAULT == null ? parkname != null : !PARKNAME_EDEFAULT.equals(parkname);
		case CensusPackage.PARK__PARKCAPACITY:
			return parkcapacity != PARKCAPACITY_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (parkname: ");
		result.append(parkname);
		result.append(", parkcapacity: ");
		result.append(parkcapacity);
		result.append(')');
		return result.toString();
	}

} //ParkImpl

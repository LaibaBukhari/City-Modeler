/**
 */
package census.impl;

import census.CensusPackage;
import census.GovtRecom;
import census.Graveyard;
import census.Hospital;
import census.House;
import census.Mosque;
import census.Other;
import census.Park;
import census.Road;
import census.School;
import census.Sector;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.WrappedException;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sector</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link census.impl.SectorImpl#getSectorname <em>Sectorname</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getSectorpopu <em>Sectorpopu</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getNofhouses <em>Nofhouses</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getNofroads <em>Nofroads</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getNofschools <em>Nofschools</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getNofparks <em>Nofparks</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getNofmosques <em>Nofmosques</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getNofhospitals <em>Nofhospitals</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getNofgraveyards <em>Nofgraveyards</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getNofothers <em>Nofothers</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getSchool <em>School</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getPark <em>Park</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getMosque <em>Mosque</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getOther <em>Other</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getGraveyard <em>Graveyard</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getHospital <em>Hospital</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getHouse <em>House</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getRoad <em>Road</em>}</li>
 *   <li>{@link census.impl.SectorImpl#getGovtrecom <em>Govtrecom</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SectorImpl extends MinimalEObjectImpl.Container implements Sector {
	/**
	 * The default value of the '{@link #getSectorname() <em>Sectorname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSectorname()
	 * @generated
	 * @ordered
	 */
	protected static final String SECTORNAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSectorname() <em>Sectorname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSectorname()
	 * @generated
	 * @ordered
	 */
	protected String sectorname = SECTORNAME_EDEFAULT;

	/**
	 * The cached setting delegate for the '{@link #getSectorpopu() <em>Sectorpopu</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSectorpopu()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate SECTORPOPU__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.SECTOR__SECTORPOPU)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getNofhouses() <em>Nofhouses</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNofhouses()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate NOFHOUSES__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.SECTOR__NOFHOUSES)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getNofroads() <em>Nofroads</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNofroads()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate NOFROADS__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.SECTOR__NOFROADS)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getNofschools() <em>Nofschools</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNofschools()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate NOFSCHOOLS__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.SECTOR__NOFSCHOOLS)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getNofparks() <em>Nofparks</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNofparks()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate NOFPARKS__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.SECTOR__NOFPARKS)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getNofmosques() <em>Nofmosques</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNofmosques()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate NOFMOSQUES__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.SECTOR__NOFMOSQUES)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getNofhospitals() <em>Nofhospitals</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNofhospitals()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate NOFHOSPITALS__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.SECTOR__NOFHOSPITALS)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getNofgraveyards() <em>Nofgraveyards</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNofgraveyards()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate NOFGRAVEYARDS__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.SECTOR__NOFGRAVEYARDS)
			.getSettingDelegate();

	/**
	 * The cached setting delegate for the '{@link #getNofothers() <em>Nofothers</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNofothers()
	 * @generated
	 * @ordered
	 */
	protected EStructuralFeature.Internal.SettingDelegate NOFOTHERS__ESETTING_DELEGATE = ((EStructuralFeature.Internal) CensusPackage.Literals.SECTOR__NOFOTHERS)
			.getSettingDelegate();

	/**
	 * The cached value of the '{@link #getSchool() <em>School</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSchool()
	 * @generated
	 * @ordered
	 */
	protected EList<School> school;

	/**
	 * The cached value of the '{@link #getPark() <em>Park</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPark()
	 * @generated
	 * @ordered
	 */
	protected EList<Park> park;

	/**
	 * The cached value of the '{@link #getMosque() <em>Mosque</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMosque()
	 * @generated
	 * @ordered
	 */
	protected EList<Mosque> mosque;

	/**
	 * The cached value of the '{@link #getOther() <em>Other</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOther()
	 * @generated
	 * @ordered
	 */
	protected EList<Other> other;

	/**
	 * The cached value of the '{@link #getGraveyard() <em>Graveyard</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGraveyard()
	 * @generated
	 * @ordered
	 */
	protected EList<Graveyard> graveyard;

	/**
	 * The cached value of the '{@link #getHospital() <em>Hospital</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHospital()
	 * @generated
	 * @ordered
	 */
	protected EList<Hospital> hospital;

	/**
	 * The cached value of the '{@link #getHouse() <em>House</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHouse()
	 * @generated
	 * @ordered
	 */
	protected EList<House> house;

	/**
	 * The cached value of the '{@link #getRoad() <em>Road</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoad()
	 * @generated
	 * @ordered
	 */
	protected EList<Road> road;

	/**
	 * The cached value of the '{@link #getGovtrecom() <em>Govtrecom</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGovtrecom()
	 * @generated
	 * @ordered
	 */
	protected GovtRecom govtrecom;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SectorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CensusPackage.Literals.SECTOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSectorname() {
		return sectorname;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSectorname(String newSectorname) {
		String oldSectorname = sectorname;
		sectorname = newSectorname;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.SECTOR__SECTORNAME, oldSectorname,
					sectorname));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getSectorpopu() {
		return (Integer) SECTORPOPU__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSectorpopu(int newSectorpopu) {
		SECTORPOPU__ESETTING_DELEGATE.dynamicSet(this, null, 0, newSectorpopu);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNofhouses() {
		return (Integer) NOFHOUSES__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNofhouses(int newNofhouses) {
		NOFHOUSES__ESETTING_DELEGATE.dynamicSet(this, null, 0, newNofhouses);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNofroads() {
		return (Integer) NOFROADS__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNofroads(int newNofroads) {
		NOFROADS__ESETTING_DELEGATE.dynamicSet(this, null, 0, newNofroads);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNofschools() {
		return (Integer) NOFSCHOOLS__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNofschools(int newNofschools) {
		NOFSCHOOLS__ESETTING_DELEGATE.dynamicSet(this, null, 0, newNofschools);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNofparks() {
		return (Integer) NOFPARKS__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNofparks(int newNofparks) {
		NOFPARKS__ESETTING_DELEGATE.dynamicSet(this, null, 0, newNofparks);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNofmosques() {
		return (Integer) NOFMOSQUES__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNofmosques(int newNofmosques) {
		NOFMOSQUES__ESETTING_DELEGATE.dynamicSet(this, null, 0, newNofmosques);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNofhospitals() {
		return (Integer) NOFHOSPITALS__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNofhospitals(int newNofhospitals) {
		NOFHOSPITALS__ESETTING_DELEGATE.dynamicSet(this, null, 0, newNofhospitals);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNofgraveyards() {
		return (Integer) NOFGRAVEYARDS__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNofgraveyards(int newNofgraveyards) {
		NOFGRAVEYARDS__ESETTING_DELEGATE.dynamicSet(this, null, 0, newNofgraveyards);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNofothers() {
		return (Integer) NOFOTHERS__ESETTING_DELEGATE.dynamicGet(this, null, 0, true, false);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNofothers(int newNofothers) {
		NOFOTHERS__ESETTING_DELEGATE.dynamicSet(this, null, 0, newNofothers);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<School> getSchool() {
		if (school == null) {
			school = new EObjectContainmentEList<School>(School.class, this, CensusPackage.SECTOR__SCHOOL);
		}
		return school;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Park> getPark() {
		if (park == null) {
			park = new EObjectContainmentEList<Park>(Park.class, this, CensusPackage.SECTOR__PARK);
		}
		return park;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Mosque> getMosque() {
		if (mosque == null) {
			mosque = new EObjectContainmentEList<Mosque>(Mosque.class, this, CensusPackage.SECTOR__MOSQUE);
		}
		return mosque;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Other> getOther() {
		if (other == null) {
			other = new EObjectContainmentEList<Other>(Other.class, this, CensusPackage.SECTOR__OTHER);
		}
		return other;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Graveyard> getGraveyard() {
		if (graveyard == null) {
			graveyard = new EObjectContainmentEList<Graveyard>(Graveyard.class, this, CensusPackage.SECTOR__GRAVEYARD);
		}
		return graveyard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Hospital> getHospital() {
		if (hospital == null) {
			hospital = new EObjectContainmentEList<Hospital>(Hospital.class, this, CensusPackage.SECTOR__HOSPITAL);
		}
		return hospital;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<House> getHouse() {
		if (house == null) {
			house = new EObjectContainmentEList<House>(House.class, this, CensusPackage.SECTOR__HOUSE);
		}
		return house;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Road> getRoad() {
		if (road == null) {
			road = new EObjectContainmentEList<Road>(Road.class, this, CensusPackage.SECTOR__ROAD);
		}
		return road;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GovtRecom getGovtrecom() {
		if (govtrecom != null && govtrecom.eIsProxy()) {
			InternalEObject oldGovtrecom = (InternalEObject) govtrecom;
			govtrecom = (GovtRecom) eResolveProxy(oldGovtrecom);
			if (govtrecom != oldGovtrecom) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CensusPackage.SECTOR__GOVTRECOM,
							oldGovtrecom, govtrecom));
			}
		}
		return govtrecom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GovtRecom basicGetGovtrecom() {
		return govtrecom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGovtrecom(GovtRecom newGovtrecom) {
		GovtRecom oldGovtrecom = govtrecom;
		govtrecom = newGovtrecom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.SECTOR__GOVTRECOM, oldGovtrecom,
					govtrecom));
	}

	/**
	 * The cached invocation delegate for the '{@link #Compare() <em>Compare</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #Compare()
	 * @generated
	 * @ordered
	 */
	protected static final EOperation.Internal.InvocationDelegate COMPARE__EINVOCATION_DELEGATE = ((EOperation.Internal) CensusPackage.Literals.SECTOR___COMPARE)
			.getInvocationDelegate();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean Compare() {
		try {
			return (Boolean) COMPARE__EINVOCATION_DELEGATE.dynamicInvoke(this, null);
		} catch (InvocationTargetException ite) {
			throw new WrappedException(ite);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case CensusPackage.SECTOR__SCHOOL:
			return ((InternalEList<?>) getSchool()).basicRemove(otherEnd, msgs);
		case CensusPackage.SECTOR__PARK:
			return ((InternalEList<?>) getPark()).basicRemove(otherEnd, msgs);
		case CensusPackage.SECTOR__MOSQUE:
			return ((InternalEList<?>) getMosque()).basicRemove(otherEnd, msgs);
		case CensusPackage.SECTOR__OTHER:
			return ((InternalEList<?>) getOther()).basicRemove(otherEnd, msgs);
		case CensusPackage.SECTOR__GRAVEYARD:
			return ((InternalEList<?>) getGraveyard()).basicRemove(otherEnd, msgs);
		case CensusPackage.SECTOR__HOSPITAL:
			return ((InternalEList<?>) getHospital()).basicRemove(otherEnd, msgs);
		case CensusPackage.SECTOR__HOUSE:
			return ((InternalEList<?>) getHouse()).basicRemove(otherEnd, msgs);
		case CensusPackage.SECTOR__ROAD:
			return ((InternalEList<?>) getRoad()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CensusPackage.SECTOR__SECTORNAME:
			return getSectorname();
		case CensusPackage.SECTOR__SECTORPOPU:
			return getSectorpopu();
		case CensusPackage.SECTOR__NOFHOUSES:
			return getNofhouses();
		case CensusPackage.SECTOR__NOFROADS:
			return getNofroads();
		case CensusPackage.SECTOR__NOFSCHOOLS:
			return getNofschools();
		case CensusPackage.SECTOR__NOFPARKS:
			return getNofparks();
		case CensusPackage.SECTOR__NOFMOSQUES:
			return getNofmosques();
		case CensusPackage.SECTOR__NOFHOSPITALS:
			return getNofhospitals();
		case CensusPackage.SECTOR__NOFGRAVEYARDS:
			return getNofgraveyards();
		case CensusPackage.SECTOR__NOFOTHERS:
			return getNofothers();
		case CensusPackage.SECTOR__SCHOOL:
			return getSchool();
		case CensusPackage.SECTOR__PARK:
			return getPark();
		case CensusPackage.SECTOR__MOSQUE:
			return getMosque();
		case CensusPackage.SECTOR__OTHER:
			return getOther();
		case CensusPackage.SECTOR__GRAVEYARD:
			return getGraveyard();
		case CensusPackage.SECTOR__HOSPITAL:
			return getHospital();
		case CensusPackage.SECTOR__HOUSE:
			return getHouse();
		case CensusPackage.SECTOR__ROAD:
			return getRoad();
		case CensusPackage.SECTOR__GOVTRECOM:
			if (resolve)
				return getGovtrecom();
			return basicGetGovtrecom();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CensusPackage.SECTOR__SECTORNAME:
			setSectorname((String) newValue);
			return;
		case CensusPackage.SECTOR__SECTORPOPU:
			setSectorpopu((Integer) newValue);
			return;
		case CensusPackage.SECTOR__NOFHOUSES:
			setNofhouses((Integer) newValue);
			return;
		case CensusPackage.SECTOR__NOFROADS:
			setNofroads((Integer) newValue);
			return;
		case CensusPackage.SECTOR__NOFSCHOOLS:
			setNofschools((Integer) newValue);
			return;
		case CensusPackage.SECTOR__NOFPARKS:
			setNofparks((Integer) newValue);
			return;
		case CensusPackage.SECTOR__NOFMOSQUES:
			setNofmosques((Integer) newValue);
			return;
		case CensusPackage.SECTOR__NOFHOSPITALS:
			setNofhospitals((Integer) newValue);
			return;
		case CensusPackage.SECTOR__NOFGRAVEYARDS:
			setNofgraveyards((Integer) newValue);
			return;
		case CensusPackage.SECTOR__NOFOTHERS:
			setNofothers((Integer) newValue);
			return;
		case CensusPackage.SECTOR__SCHOOL:
			getSchool().clear();
			getSchool().addAll((Collection<? extends School>) newValue);
			return;
		case CensusPackage.SECTOR__PARK:
			getPark().clear();
			getPark().addAll((Collection<? extends Park>) newValue);
			return;
		case CensusPackage.SECTOR__MOSQUE:
			getMosque().clear();
			getMosque().addAll((Collection<? extends Mosque>) newValue);
			return;
		case CensusPackage.SECTOR__OTHER:
			getOther().clear();
			getOther().addAll((Collection<? extends Other>) newValue);
			return;
		case CensusPackage.SECTOR__GRAVEYARD:
			getGraveyard().clear();
			getGraveyard().addAll((Collection<? extends Graveyard>) newValue);
			return;
		case CensusPackage.SECTOR__HOSPITAL:
			getHospital().clear();
			getHospital().addAll((Collection<? extends Hospital>) newValue);
			return;
		case CensusPackage.SECTOR__HOUSE:
			getHouse().clear();
			getHouse().addAll((Collection<? extends House>) newValue);
			return;
		case CensusPackage.SECTOR__ROAD:
			getRoad().clear();
			getRoad().addAll((Collection<? extends Road>) newValue);
			return;
		case CensusPackage.SECTOR__GOVTRECOM:
			setGovtrecom((GovtRecom) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CensusPackage.SECTOR__SECTORNAME:
			setSectorname(SECTORNAME_EDEFAULT);
			return;
		case CensusPackage.SECTOR__SECTORPOPU:
			SECTORPOPU__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.SECTOR__NOFHOUSES:
			NOFHOUSES__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.SECTOR__NOFROADS:
			NOFROADS__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.SECTOR__NOFSCHOOLS:
			NOFSCHOOLS__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.SECTOR__NOFPARKS:
			NOFPARKS__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.SECTOR__NOFMOSQUES:
			NOFMOSQUES__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.SECTOR__NOFHOSPITALS:
			NOFHOSPITALS__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.SECTOR__NOFGRAVEYARDS:
			NOFGRAVEYARDS__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.SECTOR__NOFOTHERS:
			NOFOTHERS__ESETTING_DELEGATE.dynamicUnset(this, null, 0);
			return;
		case CensusPackage.SECTOR__SCHOOL:
			getSchool().clear();
			return;
		case CensusPackage.SECTOR__PARK:
			getPark().clear();
			return;
		case CensusPackage.SECTOR__MOSQUE:
			getMosque().clear();
			return;
		case CensusPackage.SECTOR__OTHER:
			getOther().clear();
			return;
		case CensusPackage.SECTOR__GRAVEYARD:
			getGraveyard().clear();
			return;
		case CensusPackage.SECTOR__HOSPITAL:
			getHospital().clear();
			return;
		case CensusPackage.SECTOR__HOUSE:
			getHouse().clear();
			return;
		case CensusPackage.SECTOR__ROAD:
			getRoad().clear();
			return;
		case CensusPackage.SECTOR__GOVTRECOM:
			setGovtrecom((GovtRecom) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CensusPackage.SECTOR__SECTORNAME:
			return SECTORNAME_EDEFAULT == null ? sectorname != null : !SECTORNAME_EDEFAULT.equals(sectorname);
		case CensusPackage.SECTOR__SECTORPOPU:
			return SECTORPOPU__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.SECTOR__NOFHOUSES:
			return NOFHOUSES__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.SECTOR__NOFROADS:
			return NOFROADS__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.SECTOR__NOFSCHOOLS:
			return NOFSCHOOLS__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.SECTOR__NOFPARKS:
			return NOFPARKS__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.SECTOR__NOFMOSQUES:
			return NOFMOSQUES__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.SECTOR__NOFHOSPITALS:
			return NOFHOSPITALS__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.SECTOR__NOFGRAVEYARDS:
			return NOFGRAVEYARDS__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.SECTOR__NOFOTHERS:
			return NOFOTHERS__ESETTING_DELEGATE.dynamicIsSet(this, null, 0);
		case CensusPackage.SECTOR__SCHOOL:
			return school != null && !school.isEmpty();
		case CensusPackage.SECTOR__PARK:
			return park != null && !park.isEmpty();
		case CensusPackage.SECTOR__MOSQUE:
			return mosque != null && !mosque.isEmpty();
		case CensusPackage.SECTOR__OTHER:
			return other != null && !other.isEmpty();
		case CensusPackage.SECTOR__GRAVEYARD:
			return graveyard != null && !graveyard.isEmpty();
		case CensusPackage.SECTOR__HOSPITAL:
			return hospital != null && !hospital.isEmpty();
		case CensusPackage.SECTOR__HOUSE:
			return house != null && !house.isEmpty();
		case CensusPackage.SECTOR__ROAD:
			return road != null && !road.isEmpty();
		case CensusPackage.SECTOR__GOVTRECOM:
			return govtrecom != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case CensusPackage.SECTOR___COMPARE:
			return Compare();
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (sectorname: ");
		result.append(sectorname);
		result.append(')');
		return result.toString();
	}

} //SectorImpl

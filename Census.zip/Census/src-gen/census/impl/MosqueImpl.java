/**
 */
package census.impl;

import census.CensusPackage;
import census.Mosque;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Mosque</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link census.impl.MosqueImpl#getMosquename <em>Mosquename</em>}</li>
 *   <li>{@link census.impl.MosqueImpl#getMosquecapacity <em>Mosquecapacity</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MosqueImpl extends MinimalEObjectImpl.Container implements Mosque {
	/**
	 * The default value of the '{@link #getMosquename() <em>Mosquename</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMosquename()
	 * @generated
	 * @ordered
	 */
	protected static final String MOSQUENAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getMosquename() <em>Mosquename</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMosquename()
	 * @generated
	 * @ordered
	 */
	protected String mosquename = MOSQUENAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getMosquecapacity() <em>Mosquecapacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMosquecapacity()
	 * @generated
	 * @ordered
	 */
	protected static final int MOSQUECAPACITY_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getMosquecapacity() <em>Mosquecapacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMosquecapacity()
	 * @generated
	 * @ordered
	 */
	protected int mosquecapacity = MOSQUECAPACITY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MosqueImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CensusPackage.Literals.MOSQUE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getMosquename() {
		return mosquename;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMosquename(String newMosquename) {
		String oldMosquename = mosquename;
		mosquename = newMosquename;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.MOSQUE__MOSQUENAME, oldMosquename,
					mosquename));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getMosquecapacity() {
		return mosquecapacity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMosquecapacity(int newMosquecapacity) {
		int oldMosquecapacity = mosquecapacity;
		mosquecapacity = newMosquecapacity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.MOSQUE__MOSQUECAPACITY,
					oldMosquecapacity, mosquecapacity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CensusPackage.MOSQUE__MOSQUENAME:
			return getMosquename();
		case CensusPackage.MOSQUE__MOSQUECAPACITY:
			return getMosquecapacity();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CensusPackage.MOSQUE__MOSQUENAME:
			setMosquename((String) newValue);
			return;
		case CensusPackage.MOSQUE__MOSQUECAPACITY:
			setMosquecapacity((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CensusPackage.MOSQUE__MOSQUENAME:
			setMosquename(MOSQUENAME_EDEFAULT);
			return;
		case CensusPackage.MOSQUE__MOSQUECAPACITY:
			setMosquecapacity(MOSQUECAPACITY_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CensusPackage.MOSQUE__MOSQUENAME:
			return MOSQUENAME_EDEFAULT == null ? mosquename != null : !MOSQUENAME_EDEFAULT.equals(mosquename);
		case CensusPackage.MOSQUE__MOSQUECAPACITY:
			return mosquecapacity != MOSQUECAPACITY_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (mosquename: ");
		result.append(mosquename);
		result.append(", mosquecapacity: ");
		result.append(mosquecapacity);
		result.append(')');
		return result.toString();
	}

} //MosqueImpl

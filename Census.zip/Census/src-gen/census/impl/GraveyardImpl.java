/**
 */
package census.impl;

import census.CensusPackage;
import census.Graveyard;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Graveyard</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link census.impl.GraveyardImpl#getGraveyardname <em>Graveyardname</em>}</li>
 *   <li>{@link census.impl.GraveyardImpl#getGraveyardcapacity <em>Graveyardcapacity</em>}</li>
 * </ul>
 *
 * @generated
 */
public class GraveyardImpl extends MinimalEObjectImpl.Container implements Graveyard {
	/**
	 * The default value of the '{@link #getGraveyardname() <em>Graveyardname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGraveyardname()
	 * @generated
	 * @ordered
	 */
	protected static final String GRAVEYARDNAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getGraveyardname() <em>Graveyardname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGraveyardname()
	 * @generated
	 * @ordered
	 */
	protected String graveyardname = GRAVEYARDNAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getGraveyardcapacity() <em>Graveyardcapacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGraveyardcapacity()
	 * @generated
	 * @ordered
	 */
	protected static final int GRAVEYARDCAPACITY_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getGraveyardcapacity() <em>Graveyardcapacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGraveyardcapacity()
	 * @generated
	 * @ordered
	 */
	protected int graveyardcapacity = GRAVEYARDCAPACITY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GraveyardImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CensusPackage.Literals.GRAVEYARD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getGraveyardname() {
		return graveyardname;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGraveyardname(String newGraveyardname) {
		String oldGraveyardname = graveyardname;
		graveyardname = newGraveyardname;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.GRAVEYARD__GRAVEYARDNAME,
					oldGraveyardname, graveyardname));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getGraveyardcapacity() {
		return graveyardcapacity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGraveyardcapacity(int newGraveyardcapacity) {
		int oldGraveyardcapacity = graveyardcapacity;
		graveyardcapacity = newGraveyardcapacity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.GRAVEYARD__GRAVEYARDCAPACITY,
					oldGraveyardcapacity, graveyardcapacity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CensusPackage.GRAVEYARD__GRAVEYARDNAME:
			return getGraveyardname();
		case CensusPackage.GRAVEYARD__GRAVEYARDCAPACITY:
			return getGraveyardcapacity();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CensusPackage.GRAVEYARD__GRAVEYARDNAME:
			setGraveyardname((String) newValue);
			return;
		case CensusPackage.GRAVEYARD__GRAVEYARDCAPACITY:
			setGraveyardcapacity((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CensusPackage.GRAVEYARD__GRAVEYARDNAME:
			setGraveyardname(GRAVEYARDNAME_EDEFAULT);
			return;
		case CensusPackage.GRAVEYARD__GRAVEYARDCAPACITY:
			setGraveyardcapacity(GRAVEYARDCAPACITY_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CensusPackage.GRAVEYARD__GRAVEYARDNAME:
			return GRAVEYARDNAME_EDEFAULT == null ? graveyardname != null
					: !GRAVEYARDNAME_EDEFAULT.equals(graveyardname);
		case CensusPackage.GRAVEYARD__GRAVEYARDCAPACITY:
			return graveyardcapacity != GRAVEYARDCAPACITY_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (graveyardname: ");
		result.append(graveyardname);
		result.append(", graveyardcapacity: ");
		result.append(graveyardcapacity);
		result.append(')');
		return result.toString();
	}

} //GraveyardImpl

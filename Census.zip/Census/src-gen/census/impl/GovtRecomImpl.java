/**
 */
package census.impl;

import census.CensusPackage;
import census.GovtRecom;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Govt Recom</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link census.impl.GovtRecomImpl#getSchemePopuControl <em>Scheme Popu Control</em>}</li>
 *   <li>{@link census.impl.GovtRecomImpl#getSectorPopuControl <em>Sector Popu Control</em>}</li>
 * </ul>
 *
 * @generated
 */
public class GovtRecomImpl extends MinimalEObjectImpl.Container implements GovtRecom {
	/**
	 * The default value of the '{@link #getSchemePopuControl() <em>Scheme Popu Control</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSchemePopuControl()
	 * @generated
	 * @ordered
	 */
	protected static final int SCHEME_POPU_CONTROL_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getSchemePopuControl() <em>Scheme Popu Control</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSchemePopuControl()
	 * @generated
	 * @ordered
	 */
	protected int schemePopuControl = SCHEME_POPU_CONTROL_EDEFAULT;

	/**
	 * The default value of the '{@link #getSectorPopuControl() <em>Sector Popu Control</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSectorPopuControl()
	 * @generated
	 * @ordered
	 */
	protected static final int SECTOR_POPU_CONTROL_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getSectorPopuControl() <em>Sector Popu Control</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSectorPopuControl()
	 * @generated
	 * @ordered
	 */
	protected int sectorPopuControl = SECTOR_POPU_CONTROL_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GovtRecomImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CensusPackage.Literals.GOVT_RECOM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getSchemePopuControl() {
		return schemePopuControl;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSchemePopuControl(int newSchemePopuControl) {
		int oldSchemePopuControl = schemePopuControl;
		schemePopuControl = newSchemePopuControl;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.GOVT_RECOM__SCHEME_POPU_CONTROL,
					oldSchemePopuControl, schemePopuControl));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getSectorPopuControl() {
		return sectorPopuControl;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSectorPopuControl(int newSectorPopuControl) {
		int oldSectorPopuControl = sectorPopuControl;
		sectorPopuControl = newSectorPopuControl;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.GOVT_RECOM__SECTOR_POPU_CONTROL,
					oldSectorPopuControl, sectorPopuControl));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CensusPackage.GOVT_RECOM__SCHEME_POPU_CONTROL:
			return getSchemePopuControl();
		case CensusPackage.GOVT_RECOM__SECTOR_POPU_CONTROL:
			return getSectorPopuControl();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CensusPackage.GOVT_RECOM__SCHEME_POPU_CONTROL:
			setSchemePopuControl((Integer) newValue);
			return;
		case CensusPackage.GOVT_RECOM__SECTOR_POPU_CONTROL:
			setSectorPopuControl((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CensusPackage.GOVT_RECOM__SCHEME_POPU_CONTROL:
			setSchemePopuControl(SCHEME_POPU_CONTROL_EDEFAULT);
			return;
		case CensusPackage.GOVT_RECOM__SECTOR_POPU_CONTROL:
			setSectorPopuControl(SECTOR_POPU_CONTROL_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CensusPackage.GOVT_RECOM__SCHEME_POPU_CONTROL:
			return schemePopuControl != SCHEME_POPU_CONTROL_EDEFAULT;
		case CensusPackage.GOVT_RECOM__SECTOR_POPU_CONTROL:
			return sectorPopuControl != SECTOR_POPU_CONTROL_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (SchemePopuControl: ");
		result.append(schemePopuControl);
		result.append(", SectorPopuControl: ");
		result.append(sectorPopuControl);
		result.append(')');
		return result.toString();
	}

} //GovtRecomImpl

/**
 */
package census.impl;

import census.CensusPackage;
import census.CityModel;
import census.GovtRecom;
import census.Graveyard;
import census.Hospital;
import census.House;
import census.HousingScheme;
import census.Mosque;
import census.Other;
import census.Park;
import census.Road;
import census.School;
import census.Sector;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>City Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link census.impl.CityModelImpl#getCityname <em>Cityname</em>}</li>
 *   <li>{@link census.impl.CityModelImpl#getHousingscheme <em>Housingscheme</em>}</li>
 *   <li>{@link census.impl.CityModelImpl#getGovtrecom <em>Govtrecom</em>}</li>
 *   <li>{@link census.impl.CityModelImpl#getHospital <em>Hospital</em>}</li>
 *   <li>{@link census.impl.CityModelImpl#getGraveyard <em>Graveyard</em>}</li>
 *   <li>{@link census.impl.CityModelImpl#getOther <em>Other</em>}</li>
 *   <li>{@link census.impl.CityModelImpl#getMosque <em>Mosque</em>}</li>
 *   <li>{@link census.impl.CityModelImpl#getRoad <em>Road</em>}</li>
 *   <li>{@link census.impl.CityModelImpl#getPark <em>Park</em>}</li>
 *   <li>{@link census.impl.CityModelImpl#getSchool <em>School</em>}</li>
 *   <li>{@link census.impl.CityModelImpl#getHouse <em>House</em>}</li>
 *   <li>{@link census.impl.CityModelImpl#getSector <em>Sector</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CityModelImpl extends MinimalEObjectImpl.Container implements CityModel {
	/**
	 * The default value of the '{@link #getCityname() <em>Cityname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCityname()
	 * @generated
	 * @ordered
	 */
	protected static final String CITYNAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCityname() <em>Cityname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCityname()
	 * @generated
	 * @ordered
	 */
	protected String cityname = CITYNAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getHousingscheme() <em>Housingscheme</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHousingscheme()
	 * @generated
	 * @ordered
	 */
	protected EList<HousingScheme> housingscheme;

	/**
	 * The cached value of the '{@link #getGovtrecom() <em>Govtrecom</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGovtrecom()
	 * @generated
	 * @ordered
	 */
	protected GovtRecom govtrecom;

	/**
	 * The cached value of the '{@link #getHospital() <em>Hospital</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHospital()
	 * @generated
	 * @ordered
	 */
	protected EList<Hospital> hospital;

	/**
	 * The cached value of the '{@link #getGraveyard() <em>Graveyard</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGraveyard()
	 * @generated
	 * @ordered
	 */
	protected EList<Graveyard> graveyard;

	/**
	 * The cached value of the '{@link #getOther() <em>Other</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOther()
	 * @generated
	 * @ordered
	 */
	protected EList<Other> other;

	/**
	 * The cached value of the '{@link #getMosque() <em>Mosque</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMosque()
	 * @generated
	 * @ordered
	 */
	protected EList<Mosque> mosque;

	/**
	 * The cached value of the '{@link #getRoad() <em>Road</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoad()
	 * @generated
	 * @ordered
	 */
	protected EList<Road> road;

	/**
	 * The cached value of the '{@link #getPark() <em>Park</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPark()
	 * @generated
	 * @ordered
	 */
	protected EList<Park> park;

	/**
	 * The cached value of the '{@link #getSchool() <em>School</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSchool()
	 * @generated
	 * @ordered
	 */
	protected EList<School> school;

	/**
	 * The cached value of the '{@link #getHouse() <em>House</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHouse()
	 * @generated
	 * @ordered
	 */
	protected EList<House> house;

	/**
	 * The cached value of the '{@link #getSector() <em>Sector</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSector()
	 * @generated
	 * @ordered
	 */
	protected EList<Sector> sector;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CityModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CensusPackage.Literals.CITY_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCityname() {
		return cityname;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCityname(String newCityname) {
		String oldCityname = cityname;
		cityname = newCityname;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.CITY_MODEL__CITYNAME, oldCityname,
					cityname));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<HousingScheme> getHousingscheme() {
		if (housingscheme == null) {
			housingscheme = new EObjectContainmentEList<HousingScheme>(HousingScheme.class, this,
					CensusPackage.CITY_MODEL__HOUSINGSCHEME);
		}
		return housingscheme;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GovtRecom getGovtrecom() {
		return govtrecom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetGovtrecom(GovtRecom newGovtrecom, NotificationChain msgs) {
		GovtRecom oldGovtrecom = govtrecom;
		govtrecom = newGovtrecom;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					CensusPackage.CITY_MODEL__GOVTRECOM, oldGovtrecom, newGovtrecom);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGovtrecom(GovtRecom newGovtrecom) {
		if (newGovtrecom != govtrecom) {
			NotificationChain msgs = null;
			if (govtrecom != null)
				msgs = ((InternalEObject) govtrecom).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - CensusPackage.CITY_MODEL__GOVTRECOM, null, msgs);
			if (newGovtrecom != null)
				msgs = ((InternalEObject) newGovtrecom).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - CensusPackage.CITY_MODEL__GOVTRECOM, null, msgs);
			msgs = basicSetGovtrecom(newGovtrecom, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CensusPackage.CITY_MODEL__GOVTRECOM, newGovtrecom,
					newGovtrecom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Hospital> getHospital() {
		if (hospital == null) {
			hospital = new EObjectContainmentEList<Hospital>(Hospital.class, this, CensusPackage.CITY_MODEL__HOSPITAL);
		}
		return hospital;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Graveyard> getGraveyard() {
		if (graveyard == null) {
			graveyard = new EObjectContainmentEList<Graveyard>(Graveyard.class, this,
					CensusPackage.CITY_MODEL__GRAVEYARD);
		}
		return graveyard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Other> getOther() {
		if (other == null) {
			other = new EObjectContainmentEList<Other>(Other.class, this, CensusPackage.CITY_MODEL__OTHER);
		}
		return other;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Mosque> getMosque() {
		if (mosque == null) {
			mosque = new EObjectContainmentEList<Mosque>(Mosque.class, this, CensusPackage.CITY_MODEL__MOSQUE);
		}
		return mosque;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Road> getRoad() {
		if (road == null) {
			road = new EObjectContainmentEList<Road>(Road.class, this, CensusPackage.CITY_MODEL__ROAD);
		}
		return road;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Park> getPark() {
		if (park == null) {
			park = new EObjectContainmentEList<Park>(Park.class, this, CensusPackage.CITY_MODEL__PARK);
		}
		return park;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<School> getSchool() {
		if (school == null) {
			school = new EObjectContainmentEList<School>(School.class, this, CensusPackage.CITY_MODEL__SCHOOL);
		}
		return school;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<House> getHouse() {
		if (house == null) {
			house = new EObjectContainmentEList<House>(House.class, this, CensusPackage.CITY_MODEL__HOUSE);
		}
		return house;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Sector> getSector() {
		if (sector == null) {
			sector = new EObjectContainmentEList<Sector>(Sector.class, this, CensusPackage.CITY_MODEL__SECTOR);
		}
		return sector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case CensusPackage.CITY_MODEL__HOUSINGSCHEME:
			return ((InternalEList<?>) getHousingscheme()).basicRemove(otherEnd, msgs);
		case CensusPackage.CITY_MODEL__GOVTRECOM:
			return basicSetGovtrecom(null, msgs);
		case CensusPackage.CITY_MODEL__HOSPITAL:
			return ((InternalEList<?>) getHospital()).basicRemove(otherEnd, msgs);
		case CensusPackage.CITY_MODEL__GRAVEYARD:
			return ((InternalEList<?>) getGraveyard()).basicRemove(otherEnd, msgs);
		case CensusPackage.CITY_MODEL__OTHER:
			return ((InternalEList<?>) getOther()).basicRemove(otherEnd, msgs);
		case CensusPackage.CITY_MODEL__MOSQUE:
			return ((InternalEList<?>) getMosque()).basicRemove(otherEnd, msgs);
		case CensusPackage.CITY_MODEL__ROAD:
			return ((InternalEList<?>) getRoad()).basicRemove(otherEnd, msgs);
		case CensusPackage.CITY_MODEL__PARK:
			return ((InternalEList<?>) getPark()).basicRemove(otherEnd, msgs);
		case CensusPackage.CITY_MODEL__SCHOOL:
			return ((InternalEList<?>) getSchool()).basicRemove(otherEnd, msgs);
		case CensusPackage.CITY_MODEL__HOUSE:
			return ((InternalEList<?>) getHouse()).basicRemove(otherEnd, msgs);
		case CensusPackage.CITY_MODEL__SECTOR:
			return ((InternalEList<?>) getSector()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CensusPackage.CITY_MODEL__CITYNAME:
			return getCityname();
		case CensusPackage.CITY_MODEL__HOUSINGSCHEME:
			return getHousingscheme();
		case CensusPackage.CITY_MODEL__GOVTRECOM:
			return getGovtrecom();
		case CensusPackage.CITY_MODEL__HOSPITAL:
			return getHospital();
		case CensusPackage.CITY_MODEL__GRAVEYARD:
			return getGraveyard();
		case CensusPackage.CITY_MODEL__OTHER:
			return getOther();
		case CensusPackage.CITY_MODEL__MOSQUE:
			return getMosque();
		case CensusPackage.CITY_MODEL__ROAD:
			return getRoad();
		case CensusPackage.CITY_MODEL__PARK:
			return getPark();
		case CensusPackage.CITY_MODEL__SCHOOL:
			return getSchool();
		case CensusPackage.CITY_MODEL__HOUSE:
			return getHouse();
		case CensusPackage.CITY_MODEL__SECTOR:
			return getSector();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CensusPackage.CITY_MODEL__CITYNAME:
			setCityname((String) newValue);
			return;
		case CensusPackage.CITY_MODEL__HOUSINGSCHEME:
			getHousingscheme().clear();
			getHousingscheme().addAll((Collection<? extends HousingScheme>) newValue);
			return;
		case CensusPackage.CITY_MODEL__GOVTRECOM:
			setGovtrecom((GovtRecom) newValue);
			return;
		case CensusPackage.CITY_MODEL__HOSPITAL:
			getHospital().clear();
			getHospital().addAll((Collection<? extends Hospital>) newValue);
			return;
		case CensusPackage.CITY_MODEL__GRAVEYARD:
			getGraveyard().clear();
			getGraveyard().addAll((Collection<? extends Graveyard>) newValue);
			return;
		case CensusPackage.CITY_MODEL__OTHER:
			getOther().clear();
			getOther().addAll((Collection<? extends Other>) newValue);
			return;
		case CensusPackage.CITY_MODEL__MOSQUE:
			getMosque().clear();
			getMosque().addAll((Collection<? extends Mosque>) newValue);
			return;
		case CensusPackage.CITY_MODEL__ROAD:
			getRoad().clear();
			getRoad().addAll((Collection<? extends Road>) newValue);
			return;
		case CensusPackage.CITY_MODEL__PARK:
			getPark().clear();
			getPark().addAll((Collection<? extends Park>) newValue);
			return;
		case CensusPackage.CITY_MODEL__SCHOOL:
			getSchool().clear();
			getSchool().addAll((Collection<? extends School>) newValue);
			return;
		case CensusPackage.CITY_MODEL__HOUSE:
			getHouse().clear();
			getHouse().addAll((Collection<? extends House>) newValue);
			return;
		case CensusPackage.CITY_MODEL__SECTOR:
			getSector().clear();
			getSector().addAll((Collection<? extends Sector>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CensusPackage.CITY_MODEL__CITYNAME:
			setCityname(CITYNAME_EDEFAULT);
			return;
		case CensusPackage.CITY_MODEL__HOUSINGSCHEME:
			getHousingscheme().clear();
			return;
		case CensusPackage.CITY_MODEL__GOVTRECOM:
			setGovtrecom((GovtRecom) null);
			return;
		case CensusPackage.CITY_MODEL__HOSPITAL:
			getHospital().clear();
			return;
		case CensusPackage.CITY_MODEL__GRAVEYARD:
			getGraveyard().clear();
			return;
		case CensusPackage.CITY_MODEL__OTHER:
			getOther().clear();
			return;
		case CensusPackage.CITY_MODEL__MOSQUE:
			getMosque().clear();
			return;
		case CensusPackage.CITY_MODEL__ROAD:
			getRoad().clear();
			return;
		case CensusPackage.CITY_MODEL__PARK:
			getPark().clear();
			return;
		case CensusPackage.CITY_MODEL__SCHOOL:
			getSchool().clear();
			return;
		case CensusPackage.CITY_MODEL__HOUSE:
			getHouse().clear();
			return;
		case CensusPackage.CITY_MODEL__SECTOR:
			getSector().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CensusPackage.CITY_MODEL__CITYNAME:
			return CITYNAME_EDEFAULT == null ? cityname != null : !CITYNAME_EDEFAULT.equals(cityname);
		case CensusPackage.CITY_MODEL__HOUSINGSCHEME:
			return housingscheme != null && !housingscheme.isEmpty();
		case CensusPackage.CITY_MODEL__GOVTRECOM:
			return govtrecom != null;
		case CensusPackage.CITY_MODEL__HOSPITAL:
			return hospital != null && !hospital.isEmpty();
		case CensusPackage.CITY_MODEL__GRAVEYARD:
			return graveyard != null && !graveyard.isEmpty();
		case CensusPackage.CITY_MODEL__OTHER:
			return other != null && !other.isEmpty();
		case CensusPackage.CITY_MODEL__MOSQUE:
			return mosque != null && !mosque.isEmpty();
		case CensusPackage.CITY_MODEL__ROAD:
			return road != null && !road.isEmpty();
		case CensusPackage.CITY_MODEL__PARK:
			return park != null && !park.isEmpty();
		case CensusPackage.CITY_MODEL__SCHOOL:
			return school != null && !school.isEmpty();
		case CensusPackage.CITY_MODEL__HOUSE:
			return house != null && !house.isEmpty();
		case CensusPackage.CITY_MODEL__SECTOR:
			return sector != null && !sector.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (cityname: ");
		result.append(cityname);
		result.append(')');
		return result.toString();
	}

} //CityModelImpl

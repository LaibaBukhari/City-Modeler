/**
 */
package census;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Service Road</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see census.CensusPackage#getServiceRoad()
 * @model
 * @generated
 */
public interface ServiceRoad extends Road {
} // ServiceRoad

/**
 */
package census;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hospital</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link census.Hospital#getHospitalname <em>Hospitalname</em>}</li>
 *   <li>{@link census.Hospital#getNofbeds <em>Nofbeds</em>}</li>
 * </ul>
 *
 * @see census.CensusPackage#getHospital()
 * @model
 * @generated
 */
public interface Hospital extends EObject {
	/**
	 * Returns the value of the '<em><b>Hospitalname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hospitalname</em>' attribute.
	 * @see #setHospitalname(String)
	 * @see census.CensusPackage#getHospital_Hospitalname()
	 * @model
	 * @generated
	 */
	String getHospitalname();

	/**
	 * Sets the value of the '{@link census.Hospital#getHospitalname <em>Hospitalname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Hospitalname</em>' attribute.
	 * @see #getHospitalname()
	 * @generated
	 */
	void setHospitalname(String value);

	/**
	 * Returns the value of the '<em><b>Nofbeds</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nofbeds</em>' attribute.
	 * @see #setNofbeds(int)
	 * @see census.CensusPackage#getHospital_Nofbeds()
	 * @model required="true"
	 * @generated
	 */
	int getNofbeds();

	/**
	 * Sets the value of the '{@link census.Hospital#getNofbeds <em>Nofbeds</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nofbeds</em>' attribute.
	 * @see #getNofbeds()
	 * @generated
	 */
	void setNofbeds(int value);

} // Hospital

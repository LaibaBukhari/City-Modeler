/**
 */
package census;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Road</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link census.Road#getRoadname <em>Roadname</em>}</li>
 * </ul>
 *
 * @see census.CensusPackage#getRoad()
 * @model abstract="true"
 * @generated
 */
public interface Road extends EObject {
	/**
	 * Returns the value of the '<em><b>Roadname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Roadname</em>' attribute.
	 * @see #setRoadname(String)
	 * @see census.CensusPackage#getRoad_Roadname()
	 * @model
	 * @generated
	 */
	String getRoadname();

	/**
	 * Sets the value of the '{@link census.Road#getRoadname <em>Roadname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Roadname</em>' attribute.
	 * @see #getRoadname()
	 * @generated
	 */
	void setRoadname(String value);

} // Road

/**
 */
package census;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>City Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link census.CityModel#getCityname <em>Cityname</em>}</li>
 *   <li>{@link census.CityModel#getHousingscheme <em>Housingscheme</em>}</li>
 *   <li>{@link census.CityModel#getGovtrecom <em>Govtrecom</em>}</li>
 *   <li>{@link census.CityModel#getHospital <em>Hospital</em>}</li>
 *   <li>{@link census.CityModel#getGraveyard <em>Graveyard</em>}</li>
 *   <li>{@link census.CityModel#getOther <em>Other</em>}</li>
 *   <li>{@link census.CityModel#getMosque <em>Mosque</em>}</li>
 *   <li>{@link census.CityModel#getRoad <em>Road</em>}</li>
 *   <li>{@link census.CityModel#getPark <em>Park</em>}</li>
 *   <li>{@link census.CityModel#getSchool <em>School</em>}</li>
 *   <li>{@link census.CityModel#getHouse <em>House</em>}</li>
 *   <li>{@link census.CityModel#getSector <em>Sector</em>}</li>
 * </ul>
 *
 * @see census.CensusPackage#getCityModel()
 * @model
 * @generated
 */
public interface CityModel extends EObject {
	/**
	 * Returns the value of the '<em><b>Cityname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cityname</em>' attribute.
	 * @see #setCityname(String)
	 * @see census.CensusPackage#getCityModel_Cityname()
	 * @model
	 * @generated
	 */
	String getCityname();

	/**
	 * Sets the value of the '{@link census.CityModel#getCityname <em>Cityname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cityname</em>' attribute.
	 * @see #getCityname()
	 * @generated
	 */
	void setCityname(String value);

	/**
	 * Returns the value of the '<em><b>Housingscheme</b></em>' containment reference list.
	 * The list contents are of type {@link census.HousingScheme}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Housingscheme</em>' containment reference list.
	 * @see census.CensusPackage#getCityModel_Housingscheme()
	 * @model containment="true"
	 * @generated
	 */
	EList<HousingScheme> getHousingscheme();

	/**
	 * Returns the value of the '<em><b>Govtrecom</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Govtrecom</em>' containment reference.
	 * @see #setGovtrecom(GovtRecom)
	 * @see census.CensusPackage#getCityModel_Govtrecom()
	 * @model containment="true" required="true"
	 * @generated
	 */
	GovtRecom getGovtrecom();

	/**
	 * Sets the value of the '{@link census.CityModel#getGovtrecom <em>Govtrecom</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Govtrecom</em>' containment reference.
	 * @see #getGovtrecom()
	 * @generated
	 */
	void setGovtrecom(GovtRecom value);

	/**
	 * Returns the value of the '<em><b>Hospital</b></em>' containment reference list.
	 * The list contents are of type {@link census.Hospital}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hospital</em>' containment reference list.
	 * @see census.CensusPackage#getCityModel_Hospital()
	 * @model containment="true"
	 * @generated
	 */
	EList<Hospital> getHospital();

	/**
	 * Returns the value of the '<em><b>Graveyard</b></em>' containment reference list.
	 * The list contents are of type {@link census.Graveyard}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Graveyard</em>' containment reference list.
	 * @see census.CensusPackage#getCityModel_Graveyard()
	 * @model containment="true"
	 * @generated
	 */
	EList<Graveyard> getGraveyard();

	/**
	 * Returns the value of the '<em><b>Other</b></em>' containment reference list.
	 * The list contents are of type {@link census.Other}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Other</em>' containment reference list.
	 * @see census.CensusPackage#getCityModel_Other()
	 * @model containment="true"
	 * @generated
	 */
	EList<Other> getOther();

	/**
	 * Returns the value of the '<em><b>Mosque</b></em>' containment reference list.
	 * The list contents are of type {@link census.Mosque}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mosque</em>' containment reference list.
	 * @see census.CensusPackage#getCityModel_Mosque()
	 * @model containment="true"
	 * @generated
	 */
	EList<Mosque> getMosque();

	/**
	 * Returns the value of the '<em><b>Road</b></em>' containment reference list.
	 * The list contents are of type {@link census.Road}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Road</em>' containment reference list.
	 * @see census.CensusPackage#getCityModel_Road()
	 * @model containment="true"
	 * @generated
	 */
	EList<Road> getRoad();

	/**
	 * Returns the value of the '<em><b>Park</b></em>' containment reference list.
	 * The list contents are of type {@link census.Park}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Park</em>' containment reference list.
	 * @see census.CensusPackage#getCityModel_Park()
	 * @model containment="true"
	 * @generated
	 */
	EList<Park> getPark();

	/**
	 * Returns the value of the '<em><b>School</b></em>' containment reference list.
	 * The list contents are of type {@link census.School}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>School</em>' containment reference list.
	 * @see census.CensusPackage#getCityModel_School()
	 * @model containment="true"
	 * @generated
	 */
	EList<School> getSchool();

	/**
	 * Returns the value of the '<em><b>House</b></em>' containment reference list.
	 * The list contents are of type {@link census.House}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>House</em>' containment reference list.
	 * @see census.CensusPackage#getCityModel_House()
	 * @model containment="true"
	 * @generated
	 */
	EList<House> getHouse();

	/**
	 * Returns the value of the '<em><b>Sector</b></em>' containment reference list.
	 * The list contents are of type {@link census.Sector}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sector</em>' containment reference list.
	 * @see census.CensusPackage#getCityModel_Sector()
	 * @model containment="true"
	 * @generated
	 */
	EList<Sector> getSector();

} // CityModel

/**
 */
package census;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Main Road</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see census.CensusPackage#getMainRoad()
 * @model
 * @generated
 */
public interface MainRoad extends Road {
} // MainRoad

/**
 */
package census.util;

import census.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see census.CensusPackage
 * @generated
 */
public class CensusSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static CensusPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CensusSwitch() {
		if (modelPackage == null) {
			modelPackage = CensusPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case CensusPackage.CITY_MODEL: {
			CityModel cityModel = (CityModel) theEObject;
			T result = caseCityModel(cityModel);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case CensusPackage.HOUSING_SCHEME: {
			HousingScheme housingScheme = (HousingScheme) theEObject;
			T result = caseHousingScheme(housingScheme);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case CensusPackage.SECTOR: {
			Sector sector = (Sector) theEObject;
			T result = caseSector(sector);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case CensusPackage.SCHOOL: {
			School school = (School) theEObject;
			T result = caseSchool(school);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case CensusPackage.PARK: {
			Park park = (Park) theEObject;
			T result = casePark(park);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case CensusPackage.MOSQUE: {
			Mosque mosque = (Mosque) theEObject;
			T result = caseMosque(mosque);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case CensusPackage.HOSPITAL: {
			Hospital hospital = (Hospital) theEObject;
			T result = caseHospital(hospital);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case CensusPackage.GRAVEYARD: {
			Graveyard graveyard = (Graveyard) theEObject;
			T result = caseGraveyard(graveyard);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case CensusPackage.OTHER: {
			Other other = (Other) theEObject;
			T result = caseOther(other);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case CensusPackage.HOUSE: {
			House house = (House) theEObject;
			T result = caseHouse(house);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case CensusPackage.ROAD: {
			Road road = (Road) theEObject;
			T result = caseRoad(road);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case CensusPackage.MAIN_ROAD: {
			MainRoad mainRoad = (MainRoad) theEObject;
			T result = caseMainRoad(mainRoad);
			if (result == null)
				result = caseRoad(mainRoad);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case CensusPackage.STREET_ROAD: {
			StreetRoad streetRoad = (StreetRoad) theEObject;
			T result = caseStreetRoad(streetRoad);
			if (result == null)
				result = caseRoad(streetRoad);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case CensusPackage.SERVICE_ROAD: {
			ServiceRoad serviceRoad = (ServiceRoad) theEObject;
			T result = caseServiceRoad(serviceRoad);
			if (result == null)
				result = caseRoad(serviceRoad);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case CensusPackage.GOVT_RECOM: {
			GovtRecom govtRecom = (GovtRecom) theEObject;
			T result = caseGovtRecom(govtRecom);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>City Model</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>City Model</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCityModel(CityModel object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Housing Scheme</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Housing Scheme</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHousingScheme(HousingScheme object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Sector</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Sector</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSector(Sector object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>School</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>School</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSchool(School object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Park</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Park</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePark(Park object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Mosque</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Mosque</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMosque(Mosque object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Hospital</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Hospital</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHospital(Hospital object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Graveyard</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Graveyard</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseGraveyard(Graveyard object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Other</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Other</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOther(Other object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>House</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>House</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHouse(House object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Road</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Road</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRoad(Road object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Main Road</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Main Road</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMainRoad(MainRoad object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Street Road</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Street Road</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStreetRoad(StreetRoad object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Service Road</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Service Road</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseServiceRoad(ServiceRoad object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Govt Recom</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Govt Recom</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseGovtRecom(GovtRecom object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //CensusSwitch

/**
 */
package census.util;

import census.*;

import java.util.Map;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see census.CensusPackage
 * @generated
 */
public class CensusValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final CensusValidator INSTANCE = new CensusValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "census";

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CensusValidator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
		return CensusPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		switch (classifierID) {
		case CensusPackage.CITY_MODEL:
			return validateCityModel((CityModel) value, diagnostics, context);
		case CensusPackage.HOUSING_SCHEME:
			return validateHousingScheme((HousingScheme) value, diagnostics, context);
		case CensusPackage.SECTOR:
			return validateSector((Sector) value, diagnostics, context);
		case CensusPackage.SCHOOL:
			return validateSchool((School) value, diagnostics, context);
		case CensusPackage.PARK:
			return validatePark((Park) value, diagnostics, context);
		case CensusPackage.MOSQUE:
			return validateMosque((Mosque) value, diagnostics, context);
		case CensusPackage.HOSPITAL:
			return validateHospital((Hospital) value, diagnostics, context);
		case CensusPackage.GRAVEYARD:
			return validateGraveyard((Graveyard) value, diagnostics, context);
		case CensusPackage.OTHER:
			return validateOther((Other) value, diagnostics, context);
		case CensusPackage.HOUSE:
			return validateHouse((House) value, diagnostics, context);
		case CensusPackage.ROAD:
			return validateRoad((Road) value, diagnostics, context);
		case CensusPackage.MAIN_ROAD:
			return validateMainRoad((MainRoad) value, diagnostics, context);
		case CensusPackage.STREET_ROAD:
			return validateStreetRoad((StreetRoad) value, diagnostics, context);
		case CensusPackage.SERVICE_ROAD:
			return validateServiceRoad((ServiceRoad) value, diagnostics, context);
		case CensusPackage.GOVT_RECOM:
			return validateGovtRecom((GovtRecom) value, diagnostics, context);
		default:
			return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCityModel(CityModel cityModel, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(cityModel, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateHousingScheme(HousingScheme housingScheme, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		if (!validate_NoCircularContainment(housingScheme, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(housingScheme, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(housingScheme, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(housingScheme, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(housingScheme, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(housingScheme, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(housingScheme, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(housingScheme, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(housingScheme, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateHousingScheme_HousingSchemePopulationControl(housingScheme, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the HousingSchemePopulationControl constraint of '<em>Housing Scheme</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String HOUSING_SCHEME__HOUSING_SCHEME_POPULATION_CONTROL__EEXPRESSION = "schemepopu < govtrecom.SchemePopuControl";

	/**
	 * Validates the HousingSchemePopulationControl constraint of '<em>Housing Scheme</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateHousingScheme_HousingSchemePopulationControl(HousingScheme housingScheme,
			DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate(CensusPackage.Literals.HOUSING_SCHEME, housingScheme, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "HousingSchemePopulationControl",
				HOUSING_SCHEME__HOUSING_SCHEME_POPULATION_CONTROL__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSector(Sector sector, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(sector, diagnostics, context))
			return false;
		boolean result = validate_EveryMultiplicityConforms(sector, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryDataValueConforms(sector, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryReferenceIsContained(sector, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryBidirectionalReferenceIsPaired(sector, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryProxyResolves(sector, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_UniqueID(sector, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryKeyUnique(sector, diagnostics, context);
		if (result || diagnostics != null)
			result &= validate_EveryMapEntryUnique(sector, diagnostics, context);
		if (result || diagnostics != null)
			result &= validateSector_SectorPopulationControl(sector, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the SectorPopulationControl constraint of '<em>Sector</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String SECTOR__SECTOR_POPULATION_CONTROL__EEXPRESSION = "sectorpopu < govtrecom.SectorPopuControl";

	/**
	 * Validates the SectorPopulationControl constraint of '<em>Sector</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSector_SectorPopulationControl(Sector sector, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(CensusPackage.Literals.SECTOR, sector, diagnostics, context,
				"http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot", "SectorPopulationControl",
				SECTOR__SECTOR_POPULATION_CONTROL__EEXPRESSION, Diagnostic.ERROR, DIAGNOSTIC_SOURCE, 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSchool(School school, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(school, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePark(Park park, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(park, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateMosque(Mosque mosque, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(mosque, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateHospital(Hospital hospital, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(hospital, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateGraveyard(Graveyard graveyard, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(graveyard, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateOther(Other other, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(other, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateHouse(House house, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(house, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRoad(Road road, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(road, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateMainRoad(MainRoad mainRoad, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(mainRoad, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateStreetRoad(StreetRoad streetRoad, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(streetRoad, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateServiceRoad(ServiceRoad serviceRoad, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(serviceRoad, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateGovtRecom(GovtRecom govtRecom, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(govtRecom, diagnostics, context);
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //CensusValidator

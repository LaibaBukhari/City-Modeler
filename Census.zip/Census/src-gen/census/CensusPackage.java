/**
 */
package census;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see census.CensusFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/OCL/Import ecore='http://www.eclipse.org/emf/2002/Ecore'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore invocationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' settingDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' validationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot'"
 * @generated
 */
public interface CensusPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "census";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/census";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "census";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CensusPackage eINSTANCE = census.impl.CensusPackageImpl.init();

	/**
	 * The meta object id for the '{@link census.impl.CityModelImpl <em>City Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see census.impl.CityModelImpl
	 * @see census.impl.CensusPackageImpl#getCityModel()
	 * @generated
	 */
	int CITY_MODEL = 0;

	/**
	 * The feature id for the '<em><b>Cityname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_MODEL__CITYNAME = 0;

	/**
	 * The feature id for the '<em><b>Housingscheme</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_MODEL__HOUSINGSCHEME = 1;

	/**
	 * The feature id for the '<em><b>Govtrecom</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_MODEL__GOVTRECOM = 2;

	/**
	 * The feature id for the '<em><b>Hospital</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_MODEL__HOSPITAL = 3;

	/**
	 * The feature id for the '<em><b>Graveyard</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_MODEL__GRAVEYARD = 4;

	/**
	 * The feature id for the '<em><b>Other</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_MODEL__OTHER = 5;

	/**
	 * The feature id for the '<em><b>Mosque</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_MODEL__MOSQUE = 6;

	/**
	 * The feature id for the '<em><b>Road</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_MODEL__ROAD = 7;

	/**
	 * The feature id for the '<em><b>Park</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_MODEL__PARK = 8;

	/**
	 * The feature id for the '<em><b>School</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_MODEL__SCHOOL = 9;

	/**
	 * The feature id for the '<em><b>House</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_MODEL__HOUSE = 10;

	/**
	 * The feature id for the '<em><b>Sector</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_MODEL__SECTOR = 11;

	/**
	 * The number of structural features of the '<em>City Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_MODEL_FEATURE_COUNT = 12;

	/**
	 * The number of operations of the '<em>City Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CITY_MODEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link census.impl.HousingSchemeImpl <em>Housing Scheme</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see census.impl.HousingSchemeImpl
	 * @see census.impl.CensusPackageImpl#getHousingScheme()
	 * @generated
	 */
	int HOUSING_SCHEME = 1;

	/**
	 * The feature id for the '<em><b>Schemename</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME__SCHEMENAME = 0;

	/**
	 * The feature id for the '<em><b>Schemepopu</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME__SCHEMEPOPU = 1;

	/**
	 * The feature id for the '<em><b>Totalnofhouses</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME__TOTALNOFHOUSES = 2;

	/**
	 * The feature id for the '<em><b>Totalnofroads</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME__TOTALNOFROADS = 3;

	/**
	 * The feature id for the '<em><b>Totalnofschools</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME__TOTALNOFSCHOOLS = 4;

	/**
	 * The feature id for the '<em><b>Totalnofparks</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME__TOTALNOFPARKS = 5;

	/**
	 * The feature id for the '<em><b>Totalnofmosques</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME__TOTALNOFMOSQUES = 6;

	/**
	 * The feature id for the '<em><b>Totalnofhospitals</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME__TOTALNOFHOSPITALS = 7;

	/**
	 * The feature id for the '<em><b>Totalnofgraveyards</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME__TOTALNOFGRAVEYARDS = 8;

	/**
	 * The feature id for the '<em><b>Totalnofothers</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME__TOTALNOFOTHERS = 9;

	/**
	 * The feature id for the '<em><b>Totalnofsectors</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME__TOTALNOFSECTORS = 10;

	/**
	 * The feature id for the '<em><b>Sector</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME__SECTOR = 11;

	/**
	 * The feature id for the '<em><b>Govtrecom</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME__GOVTRECOM = 12;

	/**
	 * The number of structural features of the '<em>Housing Scheme</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME_FEATURE_COUNT = 13;

	/**
	 * The operation id for the '<em>Compare</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME___COMPARE = 0;

	/**
	 * The number of operations of the '<em>Housing Scheme</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSING_SCHEME_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link census.impl.SectorImpl <em>Sector</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see census.impl.SectorImpl
	 * @see census.impl.CensusPackageImpl#getSector()
	 * @generated
	 */
	int SECTOR = 2;

	/**
	 * The feature id for the '<em><b>Sectorname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__SECTORNAME = 0;

	/**
	 * The feature id for the '<em><b>Sectorpopu</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__SECTORPOPU = 1;

	/**
	 * The feature id for the '<em><b>Nofhouses</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__NOFHOUSES = 2;

	/**
	 * The feature id for the '<em><b>Nofroads</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__NOFROADS = 3;

	/**
	 * The feature id for the '<em><b>Nofschools</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__NOFSCHOOLS = 4;

	/**
	 * The feature id for the '<em><b>Nofparks</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__NOFPARKS = 5;

	/**
	 * The feature id for the '<em><b>Nofmosques</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__NOFMOSQUES = 6;

	/**
	 * The feature id for the '<em><b>Nofhospitals</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__NOFHOSPITALS = 7;

	/**
	 * The feature id for the '<em><b>Nofgraveyards</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__NOFGRAVEYARDS = 8;

	/**
	 * The feature id for the '<em><b>Nofothers</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__NOFOTHERS = 9;

	/**
	 * The feature id for the '<em><b>School</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__SCHOOL = 10;

	/**
	 * The feature id for the '<em><b>Park</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__PARK = 11;

	/**
	 * The feature id for the '<em><b>Mosque</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__MOSQUE = 12;

	/**
	 * The feature id for the '<em><b>Other</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__OTHER = 13;

	/**
	 * The feature id for the '<em><b>Graveyard</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__GRAVEYARD = 14;

	/**
	 * The feature id for the '<em><b>Hospital</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__HOSPITAL = 15;

	/**
	 * The feature id for the '<em><b>House</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__HOUSE = 16;

	/**
	 * The feature id for the '<em><b>Road</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__ROAD = 17;

	/**
	 * The feature id for the '<em><b>Govtrecom</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR__GOVTRECOM = 18;

	/**
	 * The number of structural features of the '<em>Sector</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR_FEATURE_COUNT = 19;

	/**
	 * The operation id for the '<em>Compare</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR___COMPARE = 0;

	/**
	 * The number of operations of the '<em>Sector</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECTOR_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link census.impl.SchoolImpl <em>School</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see census.impl.SchoolImpl
	 * @see census.impl.CensusPackageImpl#getSchool()
	 * @generated
	 */
	int SCHOOL = 3;

	/**
	 * The feature id for the '<em><b>Schoolname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCHOOL__SCHOOLNAME = 0;

	/**
	 * The feature id for the '<em><b>Schoolcapacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCHOOL__SCHOOLCAPACITY = 1;

	/**
	 * The number of structural features of the '<em>School</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCHOOL_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>School</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCHOOL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link census.impl.ParkImpl <em>Park</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see census.impl.ParkImpl
	 * @see census.impl.CensusPackageImpl#getPark()
	 * @generated
	 */
	int PARK = 4;

	/**
	 * The feature id for the '<em><b>Parkname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARK__PARKNAME = 0;

	/**
	 * The feature id for the '<em><b>Parkcapacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARK__PARKCAPACITY = 1;

	/**
	 * The number of structural features of the '<em>Park</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARK_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Park</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARK_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link census.impl.MosqueImpl <em>Mosque</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see census.impl.MosqueImpl
	 * @see census.impl.CensusPackageImpl#getMosque()
	 * @generated
	 */
	int MOSQUE = 5;

	/**
	 * The feature id for the '<em><b>Mosquename</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOSQUE__MOSQUENAME = 0;

	/**
	 * The feature id for the '<em><b>Mosquecapacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOSQUE__MOSQUECAPACITY = 1;

	/**
	 * The number of structural features of the '<em>Mosque</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOSQUE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Mosque</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOSQUE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link census.impl.HospitalImpl <em>Hospital</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see census.impl.HospitalImpl
	 * @see census.impl.CensusPackageImpl#getHospital()
	 * @generated
	 */
	int HOSPITAL = 6;

	/**
	 * The feature id for the '<em><b>Hospitalname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__HOSPITALNAME = 0;

	/**
	 * The feature id for the '<em><b>Nofbeds</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__NOFBEDS = 1;

	/**
	 * The number of structural features of the '<em>Hospital</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Hospital</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link census.impl.GraveyardImpl <em>Graveyard</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see census.impl.GraveyardImpl
	 * @see census.impl.CensusPackageImpl#getGraveyard()
	 * @generated
	 */
	int GRAVEYARD = 7;

	/**
	 * The feature id for the '<em><b>Graveyardname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GRAVEYARD__GRAVEYARDNAME = 0;

	/**
	 * The feature id for the '<em><b>Graveyardcapacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GRAVEYARD__GRAVEYARDCAPACITY = 1;

	/**
	 * The number of structural features of the '<em>Graveyard</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GRAVEYARD_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Graveyard</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GRAVEYARD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link census.impl.OtherImpl <em>Other</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see census.impl.OtherImpl
	 * @see census.impl.CensusPackageImpl#getOther()
	 * @generated
	 */
	int OTHER = 8;

	/**
	 * The feature id for the '<em><b>Othername</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OTHER__OTHERNAME = 0;

	/**
	 * The feature id for the '<em><b>Othercapacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OTHER__OTHERCAPACITY = 1;

	/**
	 * The number of structural features of the '<em>Other</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OTHER_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Other</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OTHER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link census.impl.HouseImpl <em>House</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see census.impl.HouseImpl
	 * @see census.impl.CensusPackageImpl#getHouse()
	 * @generated
	 */
	int HOUSE = 9;

	/**
	 * The feature id for the '<em><b>Housenbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__HOUSENBR = 0;

	/**
	 * The feature id for the '<em><b>Streetnbr</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__STREETNBR = 1;

	/**
	 * The feature id for the '<em><b>Nofpeople</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE__NOFPEOPLE = 2;

	/**
	 * The number of structural features of the '<em>House</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>House</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOUSE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link census.impl.RoadImpl <em>Road</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see census.impl.RoadImpl
	 * @see census.impl.CensusPackageImpl#getRoad()
	 * @generated
	 */
	int ROAD = 10;

	/**
	 * The feature id for the '<em><b>Roadname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROAD__ROADNAME = 0;

	/**
	 * The number of structural features of the '<em>Road</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROAD_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Road</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROAD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link census.impl.MainRoadImpl <em>Main Road</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see census.impl.MainRoadImpl
	 * @see census.impl.CensusPackageImpl#getMainRoad()
	 * @generated
	 */
	int MAIN_ROAD = 11;

	/**
	 * The feature id for the '<em><b>Roadname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAIN_ROAD__ROADNAME = ROAD__ROADNAME;

	/**
	 * The number of structural features of the '<em>Main Road</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAIN_ROAD_FEATURE_COUNT = ROAD_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Main Road</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAIN_ROAD_OPERATION_COUNT = ROAD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link census.impl.StreetRoadImpl <em>Street Road</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see census.impl.StreetRoadImpl
	 * @see census.impl.CensusPackageImpl#getStreetRoad()
	 * @generated
	 */
	int STREET_ROAD = 12;

	/**
	 * The feature id for the '<em><b>Roadname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET_ROAD__ROADNAME = ROAD__ROADNAME;

	/**
	 * The number of structural features of the '<em>Street Road</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET_ROAD_FEATURE_COUNT = ROAD_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Street Road</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREET_ROAD_OPERATION_COUNT = ROAD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link census.impl.ServiceRoadImpl <em>Service Road</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see census.impl.ServiceRoadImpl
	 * @see census.impl.CensusPackageImpl#getServiceRoad()
	 * @generated
	 */
	int SERVICE_ROAD = 13;

	/**
	 * The feature id for the '<em><b>Roadname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_ROAD__ROADNAME = ROAD__ROADNAME;

	/**
	 * The number of structural features of the '<em>Service Road</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_ROAD_FEATURE_COUNT = ROAD_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Service Road</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_ROAD_OPERATION_COUNT = ROAD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link census.impl.GovtRecomImpl <em>Govt Recom</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see census.impl.GovtRecomImpl
	 * @see census.impl.CensusPackageImpl#getGovtRecom()
	 * @generated
	 */
	int GOVT_RECOM = 14;

	/**
	 * The feature id for the '<em><b>Scheme Popu Control</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOVT_RECOM__SCHEME_POPU_CONTROL = 0;

	/**
	 * The feature id for the '<em><b>Sector Popu Control</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOVT_RECOM__SECTOR_POPU_CONTROL = 1;

	/**
	 * The number of structural features of the '<em>Govt Recom</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOVT_RECOM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Govt Recom</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOVT_RECOM_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link census.CityModel <em>City Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>City Model</em>'.
	 * @see census.CityModel
	 * @generated
	 */
	EClass getCityModel();

	/**
	 * Returns the meta object for the attribute '{@link census.CityModel#getCityname <em>Cityname</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cityname</em>'.
	 * @see census.CityModel#getCityname()
	 * @see #getCityModel()
	 * @generated
	 */
	EAttribute getCityModel_Cityname();

	/**
	 * Returns the meta object for the containment reference list '{@link census.CityModel#getHousingscheme <em>Housingscheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Housingscheme</em>'.
	 * @see census.CityModel#getHousingscheme()
	 * @see #getCityModel()
	 * @generated
	 */
	EReference getCityModel_Housingscheme();

	/**
	 * Returns the meta object for the containment reference '{@link census.CityModel#getGovtrecom <em>Govtrecom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Govtrecom</em>'.
	 * @see census.CityModel#getGovtrecom()
	 * @see #getCityModel()
	 * @generated
	 */
	EReference getCityModel_Govtrecom();

	/**
	 * Returns the meta object for the containment reference list '{@link census.CityModel#getHospital <em>Hospital</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Hospital</em>'.
	 * @see census.CityModel#getHospital()
	 * @see #getCityModel()
	 * @generated
	 */
	EReference getCityModel_Hospital();

	/**
	 * Returns the meta object for the containment reference list '{@link census.CityModel#getGraveyard <em>Graveyard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Graveyard</em>'.
	 * @see census.CityModel#getGraveyard()
	 * @see #getCityModel()
	 * @generated
	 */
	EReference getCityModel_Graveyard();

	/**
	 * Returns the meta object for the containment reference list '{@link census.CityModel#getOther <em>Other</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Other</em>'.
	 * @see census.CityModel#getOther()
	 * @see #getCityModel()
	 * @generated
	 */
	EReference getCityModel_Other();

	/**
	 * Returns the meta object for the containment reference list '{@link census.CityModel#getMosque <em>Mosque</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Mosque</em>'.
	 * @see census.CityModel#getMosque()
	 * @see #getCityModel()
	 * @generated
	 */
	EReference getCityModel_Mosque();

	/**
	 * Returns the meta object for the containment reference list '{@link census.CityModel#getRoad <em>Road</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Road</em>'.
	 * @see census.CityModel#getRoad()
	 * @see #getCityModel()
	 * @generated
	 */
	EReference getCityModel_Road();

	/**
	 * Returns the meta object for the containment reference list '{@link census.CityModel#getPark <em>Park</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Park</em>'.
	 * @see census.CityModel#getPark()
	 * @see #getCityModel()
	 * @generated
	 */
	EReference getCityModel_Park();

	/**
	 * Returns the meta object for the containment reference list '{@link census.CityModel#getSchool <em>School</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>School</em>'.
	 * @see census.CityModel#getSchool()
	 * @see #getCityModel()
	 * @generated
	 */
	EReference getCityModel_School();

	/**
	 * Returns the meta object for the containment reference list '{@link census.CityModel#getHouse <em>House</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>House</em>'.
	 * @see census.CityModel#getHouse()
	 * @see #getCityModel()
	 * @generated
	 */
	EReference getCityModel_House();

	/**
	 * Returns the meta object for the containment reference list '{@link census.CityModel#getSector <em>Sector</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sector</em>'.
	 * @see census.CityModel#getSector()
	 * @see #getCityModel()
	 * @generated
	 */
	EReference getCityModel_Sector();

	/**
	 * Returns the meta object for class '{@link census.HousingScheme <em>Housing Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Housing Scheme</em>'.
	 * @see census.HousingScheme
	 * @generated
	 */
	EClass getHousingScheme();

	/**
	 * Returns the meta object for the attribute '{@link census.HousingScheme#getSchemename <em>Schemename</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Schemename</em>'.
	 * @see census.HousingScheme#getSchemename()
	 * @see #getHousingScheme()
	 * @generated
	 */
	EAttribute getHousingScheme_Schemename();

	/**
	 * Returns the meta object for the attribute '{@link census.HousingScheme#getSchemepopu <em>Schemepopu</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Schemepopu</em>'.
	 * @see census.HousingScheme#getSchemepopu()
	 * @see #getHousingScheme()
	 * @generated
	 */
	EAttribute getHousingScheme_Schemepopu();

	/**
	 * Returns the meta object for the attribute '{@link census.HousingScheme#getTotalnofhouses <em>Totalnofhouses</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Totalnofhouses</em>'.
	 * @see census.HousingScheme#getTotalnofhouses()
	 * @see #getHousingScheme()
	 * @generated
	 */
	EAttribute getHousingScheme_Totalnofhouses();

	/**
	 * Returns the meta object for the attribute '{@link census.HousingScheme#getTotalnofroads <em>Totalnofroads</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Totalnofroads</em>'.
	 * @see census.HousingScheme#getTotalnofroads()
	 * @see #getHousingScheme()
	 * @generated
	 */
	EAttribute getHousingScheme_Totalnofroads();

	/**
	 * Returns the meta object for the attribute '{@link census.HousingScheme#getTotalnofschools <em>Totalnofschools</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Totalnofschools</em>'.
	 * @see census.HousingScheme#getTotalnofschools()
	 * @see #getHousingScheme()
	 * @generated
	 */
	EAttribute getHousingScheme_Totalnofschools();

	/**
	 * Returns the meta object for the attribute '{@link census.HousingScheme#getTotalnofparks <em>Totalnofparks</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Totalnofparks</em>'.
	 * @see census.HousingScheme#getTotalnofparks()
	 * @see #getHousingScheme()
	 * @generated
	 */
	EAttribute getHousingScheme_Totalnofparks();

	/**
	 * Returns the meta object for the attribute '{@link census.HousingScheme#getTotalnofmosques <em>Totalnofmosques</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Totalnofmosques</em>'.
	 * @see census.HousingScheme#getTotalnofmosques()
	 * @see #getHousingScheme()
	 * @generated
	 */
	EAttribute getHousingScheme_Totalnofmosques();

	/**
	 * Returns the meta object for the attribute '{@link census.HousingScheme#getTotalnofhospitals <em>Totalnofhospitals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Totalnofhospitals</em>'.
	 * @see census.HousingScheme#getTotalnofhospitals()
	 * @see #getHousingScheme()
	 * @generated
	 */
	EAttribute getHousingScheme_Totalnofhospitals();

	/**
	 * Returns the meta object for the attribute '{@link census.HousingScheme#getTotalnofgraveyards <em>Totalnofgraveyards</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Totalnofgraveyards</em>'.
	 * @see census.HousingScheme#getTotalnofgraveyards()
	 * @see #getHousingScheme()
	 * @generated
	 */
	EAttribute getHousingScheme_Totalnofgraveyards();

	/**
	 * Returns the meta object for the attribute '{@link census.HousingScheme#getTotalnofothers <em>Totalnofothers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Totalnofothers</em>'.
	 * @see census.HousingScheme#getTotalnofothers()
	 * @see #getHousingScheme()
	 * @generated
	 */
	EAttribute getHousingScheme_Totalnofothers();

	/**
	 * Returns the meta object for the attribute '{@link census.HousingScheme#getTotalnofsectors <em>Totalnofsectors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Totalnofsectors</em>'.
	 * @see census.HousingScheme#getTotalnofsectors()
	 * @see #getHousingScheme()
	 * @generated
	 */
	EAttribute getHousingScheme_Totalnofsectors();

	/**
	 * Returns the meta object for the containment reference list '{@link census.HousingScheme#getSector <em>Sector</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sector</em>'.
	 * @see census.HousingScheme#getSector()
	 * @see #getHousingScheme()
	 * @generated
	 */
	EReference getHousingScheme_Sector();

	/**
	 * Returns the meta object for the reference '{@link census.HousingScheme#getGovtrecom <em>Govtrecom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Govtrecom</em>'.
	 * @see census.HousingScheme#getGovtrecom()
	 * @see #getHousingScheme()
	 * @generated
	 */
	EReference getHousingScheme_Govtrecom();

	/**
	 * Returns the meta object for the '{@link census.HousingScheme#Compare() <em>Compare</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Compare</em>' operation.
	 * @see census.HousingScheme#Compare()
	 * @generated
	 */
	EOperation getHousingScheme__Compare();

	/**
	 * Returns the meta object for class '{@link census.Sector <em>Sector</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sector</em>'.
	 * @see census.Sector
	 * @generated
	 */
	EClass getSector();

	/**
	 * Returns the meta object for the attribute '{@link census.Sector#getSectorname <em>Sectorname</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sectorname</em>'.
	 * @see census.Sector#getSectorname()
	 * @see #getSector()
	 * @generated
	 */
	EAttribute getSector_Sectorname();

	/**
	 * Returns the meta object for the attribute '{@link census.Sector#getSectorpopu <em>Sectorpopu</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sectorpopu</em>'.
	 * @see census.Sector#getSectorpopu()
	 * @see #getSector()
	 * @generated
	 */
	EAttribute getSector_Sectorpopu();

	/**
	 * Returns the meta object for the attribute '{@link census.Sector#getNofhouses <em>Nofhouses</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nofhouses</em>'.
	 * @see census.Sector#getNofhouses()
	 * @see #getSector()
	 * @generated
	 */
	EAttribute getSector_Nofhouses();

	/**
	 * Returns the meta object for the attribute '{@link census.Sector#getNofroads <em>Nofroads</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nofroads</em>'.
	 * @see census.Sector#getNofroads()
	 * @see #getSector()
	 * @generated
	 */
	EAttribute getSector_Nofroads();

	/**
	 * Returns the meta object for the attribute '{@link census.Sector#getNofschools <em>Nofschools</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nofschools</em>'.
	 * @see census.Sector#getNofschools()
	 * @see #getSector()
	 * @generated
	 */
	EAttribute getSector_Nofschools();

	/**
	 * Returns the meta object for the attribute '{@link census.Sector#getNofparks <em>Nofparks</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nofparks</em>'.
	 * @see census.Sector#getNofparks()
	 * @see #getSector()
	 * @generated
	 */
	EAttribute getSector_Nofparks();

	/**
	 * Returns the meta object for the attribute '{@link census.Sector#getNofmosques <em>Nofmosques</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nofmosques</em>'.
	 * @see census.Sector#getNofmosques()
	 * @see #getSector()
	 * @generated
	 */
	EAttribute getSector_Nofmosques();

	/**
	 * Returns the meta object for the attribute '{@link census.Sector#getNofhospitals <em>Nofhospitals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nofhospitals</em>'.
	 * @see census.Sector#getNofhospitals()
	 * @see #getSector()
	 * @generated
	 */
	EAttribute getSector_Nofhospitals();

	/**
	 * Returns the meta object for the attribute '{@link census.Sector#getNofgraveyards <em>Nofgraveyards</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nofgraveyards</em>'.
	 * @see census.Sector#getNofgraveyards()
	 * @see #getSector()
	 * @generated
	 */
	EAttribute getSector_Nofgraveyards();

	/**
	 * Returns the meta object for the attribute '{@link census.Sector#getNofothers <em>Nofothers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nofothers</em>'.
	 * @see census.Sector#getNofothers()
	 * @see #getSector()
	 * @generated
	 */
	EAttribute getSector_Nofothers();

	/**
	 * Returns the meta object for the containment reference list '{@link census.Sector#getSchool <em>School</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>School</em>'.
	 * @see census.Sector#getSchool()
	 * @see #getSector()
	 * @generated
	 */
	EReference getSector_School();

	/**
	 * Returns the meta object for the containment reference list '{@link census.Sector#getPark <em>Park</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Park</em>'.
	 * @see census.Sector#getPark()
	 * @see #getSector()
	 * @generated
	 */
	EReference getSector_Park();

	/**
	 * Returns the meta object for the containment reference list '{@link census.Sector#getMosque <em>Mosque</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Mosque</em>'.
	 * @see census.Sector#getMosque()
	 * @see #getSector()
	 * @generated
	 */
	EReference getSector_Mosque();

	/**
	 * Returns the meta object for the containment reference list '{@link census.Sector#getOther <em>Other</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Other</em>'.
	 * @see census.Sector#getOther()
	 * @see #getSector()
	 * @generated
	 */
	EReference getSector_Other();

	/**
	 * Returns the meta object for the containment reference list '{@link census.Sector#getGraveyard <em>Graveyard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Graveyard</em>'.
	 * @see census.Sector#getGraveyard()
	 * @see #getSector()
	 * @generated
	 */
	EReference getSector_Graveyard();

	/**
	 * Returns the meta object for the containment reference list '{@link census.Sector#getHospital <em>Hospital</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Hospital</em>'.
	 * @see census.Sector#getHospital()
	 * @see #getSector()
	 * @generated
	 */
	EReference getSector_Hospital();

	/**
	 * Returns the meta object for the containment reference list '{@link census.Sector#getHouse <em>House</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>House</em>'.
	 * @see census.Sector#getHouse()
	 * @see #getSector()
	 * @generated
	 */
	EReference getSector_House();

	/**
	 * Returns the meta object for the containment reference list '{@link census.Sector#getRoad <em>Road</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Road</em>'.
	 * @see census.Sector#getRoad()
	 * @see #getSector()
	 * @generated
	 */
	EReference getSector_Road();

	/**
	 * Returns the meta object for the reference '{@link census.Sector#getGovtrecom <em>Govtrecom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Govtrecom</em>'.
	 * @see census.Sector#getGovtrecom()
	 * @see #getSector()
	 * @generated
	 */
	EReference getSector_Govtrecom();

	/**
	 * Returns the meta object for the '{@link census.Sector#Compare() <em>Compare</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Compare</em>' operation.
	 * @see census.Sector#Compare()
	 * @generated
	 */
	EOperation getSector__Compare();

	/**
	 * Returns the meta object for class '{@link census.School <em>School</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>School</em>'.
	 * @see census.School
	 * @generated
	 */
	EClass getSchool();

	/**
	 * Returns the meta object for the attribute '{@link census.School#getSchoolname <em>Schoolname</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Schoolname</em>'.
	 * @see census.School#getSchoolname()
	 * @see #getSchool()
	 * @generated
	 */
	EAttribute getSchool_Schoolname();

	/**
	 * Returns the meta object for the attribute '{@link census.School#getSchoolcapacity <em>Schoolcapacity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Schoolcapacity</em>'.
	 * @see census.School#getSchoolcapacity()
	 * @see #getSchool()
	 * @generated
	 */
	EAttribute getSchool_Schoolcapacity();

	/**
	 * Returns the meta object for class '{@link census.Park <em>Park</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Park</em>'.
	 * @see census.Park
	 * @generated
	 */
	EClass getPark();

	/**
	 * Returns the meta object for the attribute '{@link census.Park#getParkname <em>Parkname</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Parkname</em>'.
	 * @see census.Park#getParkname()
	 * @see #getPark()
	 * @generated
	 */
	EAttribute getPark_Parkname();

	/**
	 * Returns the meta object for the attribute '{@link census.Park#getParkcapacity <em>Parkcapacity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Parkcapacity</em>'.
	 * @see census.Park#getParkcapacity()
	 * @see #getPark()
	 * @generated
	 */
	EAttribute getPark_Parkcapacity();

	/**
	 * Returns the meta object for class '{@link census.Mosque <em>Mosque</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Mosque</em>'.
	 * @see census.Mosque
	 * @generated
	 */
	EClass getMosque();

	/**
	 * Returns the meta object for the attribute '{@link census.Mosque#getMosquename <em>Mosquename</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mosquename</em>'.
	 * @see census.Mosque#getMosquename()
	 * @see #getMosque()
	 * @generated
	 */
	EAttribute getMosque_Mosquename();

	/**
	 * Returns the meta object for the attribute '{@link census.Mosque#getMosquecapacity <em>Mosquecapacity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Mosquecapacity</em>'.
	 * @see census.Mosque#getMosquecapacity()
	 * @see #getMosque()
	 * @generated
	 */
	EAttribute getMosque_Mosquecapacity();

	/**
	 * Returns the meta object for class '{@link census.Hospital <em>Hospital</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Hospital</em>'.
	 * @see census.Hospital
	 * @generated
	 */
	EClass getHospital();

	/**
	 * Returns the meta object for the attribute '{@link census.Hospital#getHospitalname <em>Hospitalname</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Hospitalname</em>'.
	 * @see census.Hospital#getHospitalname()
	 * @see #getHospital()
	 * @generated
	 */
	EAttribute getHospital_Hospitalname();

	/**
	 * Returns the meta object for the attribute '{@link census.Hospital#getNofbeds <em>Nofbeds</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nofbeds</em>'.
	 * @see census.Hospital#getNofbeds()
	 * @see #getHospital()
	 * @generated
	 */
	EAttribute getHospital_Nofbeds();

	/**
	 * Returns the meta object for class '{@link census.Graveyard <em>Graveyard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Graveyard</em>'.
	 * @see census.Graveyard
	 * @generated
	 */
	EClass getGraveyard();

	/**
	 * Returns the meta object for the attribute '{@link census.Graveyard#getGraveyardname <em>Graveyardname</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Graveyardname</em>'.
	 * @see census.Graveyard#getGraveyardname()
	 * @see #getGraveyard()
	 * @generated
	 */
	EAttribute getGraveyard_Graveyardname();

	/**
	 * Returns the meta object for the attribute '{@link census.Graveyard#getGraveyardcapacity <em>Graveyardcapacity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Graveyardcapacity</em>'.
	 * @see census.Graveyard#getGraveyardcapacity()
	 * @see #getGraveyard()
	 * @generated
	 */
	EAttribute getGraveyard_Graveyardcapacity();

	/**
	 * Returns the meta object for class '{@link census.Other <em>Other</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Other</em>'.
	 * @see census.Other
	 * @generated
	 */
	EClass getOther();

	/**
	 * Returns the meta object for the attribute '{@link census.Other#getOthername <em>Othername</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Othername</em>'.
	 * @see census.Other#getOthername()
	 * @see #getOther()
	 * @generated
	 */
	EAttribute getOther_Othername();

	/**
	 * Returns the meta object for the attribute '{@link census.Other#getOthercapacity <em>Othercapacity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Othercapacity</em>'.
	 * @see census.Other#getOthercapacity()
	 * @see #getOther()
	 * @generated
	 */
	EAttribute getOther_Othercapacity();

	/**
	 * Returns the meta object for class '{@link census.House <em>House</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>House</em>'.
	 * @see census.House
	 * @generated
	 */
	EClass getHouse();

	/**
	 * Returns the meta object for the attribute '{@link census.House#getHousenbr <em>Housenbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Housenbr</em>'.
	 * @see census.House#getHousenbr()
	 * @see #getHouse()
	 * @generated
	 */
	EAttribute getHouse_Housenbr();

	/**
	 * Returns the meta object for the attribute '{@link census.House#getStreetnbr <em>Streetnbr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Streetnbr</em>'.
	 * @see census.House#getStreetnbr()
	 * @see #getHouse()
	 * @generated
	 */
	EAttribute getHouse_Streetnbr();

	/**
	 * Returns the meta object for the attribute '{@link census.House#getNofpeople <em>Nofpeople</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nofpeople</em>'.
	 * @see census.House#getNofpeople()
	 * @see #getHouse()
	 * @generated
	 */
	EAttribute getHouse_Nofpeople();

	/**
	 * Returns the meta object for class '{@link census.Road <em>Road</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Road</em>'.
	 * @see census.Road
	 * @generated
	 */
	EClass getRoad();

	/**
	 * Returns the meta object for the attribute '{@link census.Road#getRoadname <em>Roadname</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Roadname</em>'.
	 * @see census.Road#getRoadname()
	 * @see #getRoad()
	 * @generated
	 */
	EAttribute getRoad_Roadname();

	/**
	 * Returns the meta object for class '{@link census.MainRoad <em>Main Road</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Main Road</em>'.
	 * @see census.MainRoad
	 * @generated
	 */
	EClass getMainRoad();

	/**
	 * Returns the meta object for class '{@link census.StreetRoad <em>Street Road</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Street Road</em>'.
	 * @see census.StreetRoad
	 * @generated
	 */
	EClass getStreetRoad();

	/**
	 * Returns the meta object for class '{@link census.ServiceRoad <em>Service Road</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Service Road</em>'.
	 * @see census.ServiceRoad
	 * @generated
	 */
	EClass getServiceRoad();

	/**
	 * Returns the meta object for class '{@link census.GovtRecom <em>Govt Recom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Govt Recom</em>'.
	 * @see census.GovtRecom
	 * @generated
	 */
	EClass getGovtRecom();

	/**
	 * Returns the meta object for the attribute '{@link census.GovtRecom#getSchemePopuControl <em>Scheme Popu Control</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Scheme Popu Control</em>'.
	 * @see census.GovtRecom#getSchemePopuControl()
	 * @see #getGovtRecom()
	 * @generated
	 */
	EAttribute getGovtRecom_SchemePopuControl();

	/**
	 * Returns the meta object for the attribute '{@link census.GovtRecom#getSectorPopuControl <em>Sector Popu Control</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sector Popu Control</em>'.
	 * @see census.GovtRecom#getSectorPopuControl()
	 * @see #getGovtRecom()
	 * @generated
	 */
	EAttribute getGovtRecom_SectorPopuControl();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	CensusFactory getCensusFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link census.impl.CityModelImpl <em>City Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see census.impl.CityModelImpl
		 * @see census.impl.CensusPackageImpl#getCityModel()
		 * @generated
		 */
		EClass CITY_MODEL = eINSTANCE.getCityModel();

		/**
		 * The meta object literal for the '<em><b>Cityname</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CITY_MODEL__CITYNAME = eINSTANCE.getCityModel_Cityname();

		/**
		 * The meta object literal for the '<em><b>Housingscheme</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CITY_MODEL__HOUSINGSCHEME = eINSTANCE.getCityModel_Housingscheme();

		/**
		 * The meta object literal for the '<em><b>Govtrecom</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CITY_MODEL__GOVTRECOM = eINSTANCE.getCityModel_Govtrecom();

		/**
		 * The meta object literal for the '<em><b>Hospital</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CITY_MODEL__HOSPITAL = eINSTANCE.getCityModel_Hospital();

		/**
		 * The meta object literal for the '<em><b>Graveyard</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CITY_MODEL__GRAVEYARD = eINSTANCE.getCityModel_Graveyard();

		/**
		 * The meta object literal for the '<em><b>Other</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CITY_MODEL__OTHER = eINSTANCE.getCityModel_Other();

		/**
		 * The meta object literal for the '<em><b>Mosque</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CITY_MODEL__MOSQUE = eINSTANCE.getCityModel_Mosque();

		/**
		 * The meta object literal for the '<em><b>Road</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CITY_MODEL__ROAD = eINSTANCE.getCityModel_Road();

		/**
		 * The meta object literal for the '<em><b>Park</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CITY_MODEL__PARK = eINSTANCE.getCityModel_Park();

		/**
		 * The meta object literal for the '<em><b>School</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CITY_MODEL__SCHOOL = eINSTANCE.getCityModel_School();

		/**
		 * The meta object literal for the '<em><b>House</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CITY_MODEL__HOUSE = eINSTANCE.getCityModel_House();

		/**
		 * The meta object literal for the '<em><b>Sector</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CITY_MODEL__SECTOR = eINSTANCE.getCityModel_Sector();

		/**
		 * The meta object literal for the '{@link census.impl.HousingSchemeImpl <em>Housing Scheme</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see census.impl.HousingSchemeImpl
		 * @see census.impl.CensusPackageImpl#getHousingScheme()
		 * @generated
		 */
		EClass HOUSING_SCHEME = eINSTANCE.getHousingScheme();

		/**
		 * The meta object literal for the '<em><b>Schemename</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOUSING_SCHEME__SCHEMENAME = eINSTANCE.getHousingScheme_Schemename();

		/**
		 * The meta object literal for the '<em><b>Schemepopu</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOUSING_SCHEME__SCHEMEPOPU = eINSTANCE.getHousingScheme_Schemepopu();

		/**
		 * The meta object literal for the '<em><b>Totalnofhouses</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOUSING_SCHEME__TOTALNOFHOUSES = eINSTANCE.getHousingScheme_Totalnofhouses();

		/**
		 * The meta object literal for the '<em><b>Totalnofroads</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOUSING_SCHEME__TOTALNOFROADS = eINSTANCE.getHousingScheme_Totalnofroads();

		/**
		 * The meta object literal for the '<em><b>Totalnofschools</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOUSING_SCHEME__TOTALNOFSCHOOLS = eINSTANCE.getHousingScheme_Totalnofschools();

		/**
		 * The meta object literal for the '<em><b>Totalnofparks</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOUSING_SCHEME__TOTALNOFPARKS = eINSTANCE.getHousingScheme_Totalnofparks();

		/**
		 * The meta object literal for the '<em><b>Totalnofmosques</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOUSING_SCHEME__TOTALNOFMOSQUES = eINSTANCE.getHousingScheme_Totalnofmosques();

		/**
		 * The meta object literal for the '<em><b>Totalnofhospitals</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOUSING_SCHEME__TOTALNOFHOSPITALS = eINSTANCE.getHousingScheme_Totalnofhospitals();

		/**
		 * The meta object literal for the '<em><b>Totalnofgraveyards</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOUSING_SCHEME__TOTALNOFGRAVEYARDS = eINSTANCE.getHousingScheme_Totalnofgraveyards();

		/**
		 * The meta object literal for the '<em><b>Totalnofothers</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOUSING_SCHEME__TOTALNOFOTHERS = eINSTANCE.getHousingScheme_Totalnofothers();

		/**
		 * The meta object literal for the '<em><b>Totalnofsectors</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOUSING_SCHEME__TOTALNOFSECTORS = eINSTANCE.getHousingScheme_Totalnofsectors();

		/**
		 * The meta object literal for the '<em><b>Sector</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOUSING_SCHEME__SECTOR = eINSTANCE.getHousingScheme_Sector();

		/**
		 * The meta object literal for the '<em><b>Govtrecom</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOUSING_SCHEME__GOVTRECOM = eINSTANCE.getHousingScheme_Govtrecom();

		/**
		 * The meta object literal for the '<em><b>Compare</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation HOUSING_SCHEME___COMPARE = eINSTANCE.getHousingScheme__Compare();

		/**
		 * The meta object literal for the '{@link census.impl.SectorImpl <em>Sector</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see census.impl.SectorImpl
		 * @see census.impl.CensusPackageImpl#getSector()
		 * @generated
		 */
		EClass SECTOR = eINSTANCE.getSector();

		/**
		 * The meta object literal for the '<em><b>Sectorname</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SECTOR__SECTORNAME = eINSTANCE.getSector_Sectorname();

		/**
		 * The meta object literal for the '<em><b>Sectorpopu</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SECTOR__SECTORPOPU = eINSTANCE.getSector_Sectorpopu();

		/**
		 * The meta object literal for the '<em><b>Nofhouses</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SECTOR__NOFHOUSES = eINSTANCE.getSector_Nofhouses();

		/**
		 * The meta object literal for the '<em><b>Nofroads</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SECTOR__NOFROADS = eINSTANCE.getSector_Nofroads();

		/**
		 * The meta object literal for the '<em><b>Nofschools</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SECTOR__NOFSCHOOLS = eINSTANCE.getSector_Nofschools();

		/**
		 * The meta object literal for the '<em><b>Nofparks</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SECTOR__NOFPARKS = eINSTANCE.getSector_Nofparks();

		/**
		 * The meta object literal for the '<em><b>Nofmosques</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SECTOR__NOFMOSQUES = eINSTANCE.getSector_Nofmosques();

		/**
		 * The meta object literal for the '<em><b>Nofhospitals</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SECTOR__NOFHOSPITALS = eINSTANCE.getSector_Nofhospitals();

		/**
		 * The meta object literal for the '<em><b>Nofgraveyards</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SECTOR__NOFGRAVEYARDS = eINSTANCE.getSector_Nofgraveyards();

		/**
		 * The meta object literal for the '<em><b>Nofothers</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SECTOR__NOFOTHERS = eINSTANCE.getSector_Nofothers();

		/**
		 * The meta object literal for the '<em><b>School</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SECTOR__SCHOOL = eINSTANCE.getSector_School();

		/**
		 * The meta object literal for the '<em><b>Park</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SECTOR__PARK = eINSTANCE.getSector_Park();

		/**
		 * The meta object literal for the '<em><b>Mosque</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SECTOR__MOSQUE = eINSTANCE.getSector_Mosque();

		/**
		 * The meta object literal for the '<em><b>Other</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SECTOR__OTHER = eINSTANCE.getSector_Other();

		/**
		 * The meta object literal for the '<em><b>Graveyard</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SECTOR__GRAVEYARD = eINSTANCE.getSector_Graveyard();

		/**
		 * The meta object literal for the '<em><b>Hospital</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SECTOR__HOSPITAL = eINSTANCE.getSector_Hospital();

		/**
		 * The meta object literal for the '<em><b>House</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SECTOR__HOUSE = eINSTANCE.getSector_House();

		/**
		 * The meta object literal for the '<em><b>Road</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SECTOR__ROAD = eINSTANCE.getSector_Road();

		/**
		 * The meta object literal for the '<em><b>Govtrecom</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SECTOR__GOVTRECOM = eINSTANCE.getSector_Govtrecom();

		/**
		 * The meta object literal for the '<em><b>Compare</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SECTOR___COMPARE = eINSTANCE.getSector__Compare();

		/**
		 * The meta object literal for the '{@link census.impl.SchoolImpl <em>School</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see census.impl.SchoolImpl
		 * @see census.impl.CensusPackageImpl#getSchool()
		 * @generated
		 */
		EClass SCHOOL = eINSTANCE.getSchool();

		/**
		 * The meta object literal for the '<em><b>Schoolname</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SCHOOL__SCHOOLNAME = eINSTANCE.getSchool_Schoolname();

		/**
		 * The meta object literal for the '<em><b>Schoolcapacity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SCHOOL__SCHOOLCAPACITY = eINSTANCE.getSchool_Schoolcapacity();

		/**
		 * The meta object literal for the '{@link census.impl.ParkImpl <em>Park</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see census.impl.ParkImpl
		 * @see census.impl.CensusPackageImpl#getPark()
		 * @generated
		 */
		EClass PARK = eINSTANCE.getPark();

		/**
		 * The meta object literal for the '<em><b>Parkname</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARK__PARKNAME = eINSTANCE.getPark_Parkname();

		/**
		 * The meta object literal for the '<em><b>Parkcapacity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARK__PARKCAPACITY = eINSTANCE.getPark_Parkcapacity();

		/**
		 * The meta object literal for the '{@link census.impl.MosqueImpl <em>Mosque</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see census.impl.MosqueImpl
		 * @see census.impl.CensusPackageImpl#getMosque()
		 * @generated
		 */
		EClass MOSQUE = eINSTANCE.getMosque();

		/**
		 * The meta object literal for the '<em><b>Mosquename</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOSQUE__MOSQUENAME = eINSTANCE.getMosque_Mosquename();

		/**
		 * The meta object literal for the '<em><b>Mosquecapacity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOSQUE__MOSQUECAPACITY = eINSTANCE.getMosque_Mosquecapacity();

		/**
		 * The meta object literal for the '{@link census.impl.HospitalImpl <em>Hospital</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see census.impl.HospitalImpl
		 * @see census.impl.CensusPackageImpl#getHospital()
		 * @generated
		 */
		EClass HOSPITAL = eINSTANCE.getHospital();

		/**
		 * The meta object literal for the '<em><b>Hospitalname</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOSPITAL__HOSPITALNAME = eINSTANCE.getHospital_Hospitalname();

		/**
		 * The meta object literal for the '<em><b>Nofbeds</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOSPITAL__NOFBEDS = eINSTANCE.getHospital_Nofbeds();

		/**
		 * The meta object literal for the '{@link census.impl.GraveyardImpl <em>Graveyard</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see census.impl.GraveyardImpl
		 * @see census.impl.CensusPackageImpl#getGraveyard()
		 * @generated
		 */
		EClass GRAVEYARD = eINSTANCE.getGraveyard();

		/**
		 * The meta object literal for the '<em><b>Graveyardname</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GRAVEYARD__GRAVEYARDNAME = eINSTANCE.getGraveyard_Graveyardname();

		/**
		 * The meta object literal for the '<em><b>Graveyardcapacity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GRAVEYARD__GRAVEYARDCAPACITY = eINSTANCE.getGraveyard_Graveyardcapacity();

		/**
		 * The meta object literal for the '{@link census.impl.OtherImpl <em>Other</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see census.impl.OtherImpl
		 * @see census.impl.CensusPackageImpl#getOther()
		 * @generated
		 */
		EClass OTHER = eINSTANCE.getOther();

		/**
		 * The meta object literal for the '<em><b>Othername</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OTHER__OTHERNAME = eINSTANCE.getOther_Othername();

		/**
		 * The meta object literal for the '<em><b>Othercapacity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OTHER__OTHERCAPACITY = eINSTANCE.getOther_Othercapacity();

		/**
		 * The meta object literal for the '{@link census.impl.HouseImpl <em>House</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see census.impl.HouseImpl
		 * @see census.impl.CensusPackageImpl#getHouse()
		 * @generated
		 */
		EClass HOUSE = eINSTANCE.getHouse();

		/**
		 * The meta object literal for the '<em><b>Housenbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOUSE__HOUSENBR = eINSTANCE.getHouse_Housenbr();

		/**
		 * The meta object literal for the '<em><b>Streetnbr</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOUSE__STREETNBR = eINSTANCE.getHouse_Streetnbr();

		/**
		 * The meta object literal for the '<em><b>Nofpeople</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HOUSE__NOFPEOPLE = eINSTANCE.getHouse_Nofpeople();

		/**
		 * The meta object literal for the '{@link census.impl.RoadImpl <em>Road</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see census.impl.RoadImpl
		 * @see census.impl.CensusPackageImpl#getRoad()
		 * @generated
		 */
		EClass ROAD = eINSTANCE.getRoad();

		/**
		 * The meta object literal for the '<em><b>Roadname</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROAD__ROADNAME = eINSTANCE.getRoad_Roadname();

		/**
		 * The meta object literal for the '{@link census.impl.MainRoadImpl <em>Main Road</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see census.impl.MainRoadImpl
		 * @see census.impl.CensusPackageImpl#getMainRoad()
		 * @generated
		 */
		EClass MAIN_ROAD = eINSTANCE.getMainRoad();

		/**
		 * The meta object literal for the '{@link census.impl.StreetRoadImpl <em>Street Road</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see census.impl.StreetRoadImpl
		 * @see census.impl.CensusPackageImpl#getStreetRoad()
		 * @generated
		 */
		EClass STREET_ROAD = eINSTANCE.getStreetRoad();

		/**
		 * The meta object literal for the '{@link census.impl.ServiceRoadImpl <em>Service Road</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see census.impl.ServiceRoadImpl
		 * @see census.impl.CensusPackageImpl#getServiceRoad()
		 * @generated
		 */
		EClass SERVICE_ROAD = eINSTANCE.getServiceRoad();

		/**
		 * The meta object literal for the '{@link census.impl.GovtRecomImpl <em>Govt Recom</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see census.impl.GovtRecomImpl
		 * @see census.impl.CensusPackageImpl#getGovtRecom()
		 * @generated
		 */
		EClass GOVT_RECOM = eINSTANCE.getGovtRecom();

		/**
		 * The meta object literal for the '<em><b>Scheme Popu Control</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GOVT_RECOM__SCHEME_POPU_CONTROL = eINSTANCE.getGovtRecom_SchemePopuControl();

		/**
		 * The meta object literal for the '<em><b>Sector Popu Control</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GOVT_RECOM__SECTOR_POPU_CONTROL = eINSTANCE.getGovtRecom_SectorPopuControl();

	}

} //CensusPackage
